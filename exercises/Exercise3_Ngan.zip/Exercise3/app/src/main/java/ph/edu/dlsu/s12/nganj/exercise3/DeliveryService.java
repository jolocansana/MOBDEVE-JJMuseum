package ph.edu.dlsu.s12.nganj.exercise3;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import java.util.Calendar;
import java.util.Timer;

public class DeliveryService extends Service {

    public static final int notify = 1000;
    private Handler mHandler = new Handler();
    private Timer mTimer = null;
    final int delay = 10000;
    private int i = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        if (mTimer != null)
            mTimer.cancel();
        else
            mTimer = new Timer();

        mHandler.postDelayed(new Runnable() {
            public void run() {

                Calendar calendar = Calendar.getInstance();
                long seconds = calendar.get(Calendar.SECOND);
                Log.d("Service", "Calling Location: " + seconds);

            i++;

                if (i == 1) {
                    MainActivity.checkFirst();
                    Log.d("Service", "Calling Location: " + seconds);
                }
                else if (i == 2) {
                    MainActivity.checkSecond();
                }
                else if (i == 3) {
                    MainActivity.checkThird();
                }
                else if (i == 4) {
                    MainActivity.checkFourth();
                }
                else if (i== 5) {
                    MainActivity.checkFifth();
                }
                else if (i == 6) {
                    MainActivity.checkSixth();
                }


            mHandler.postDelayed(this, delay);


            }
        }, delay);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        mTimer.cancel();
    }


}
