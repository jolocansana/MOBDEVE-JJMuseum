package ph.edu.dlsu.s12.cansana.sentonlyemail;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansana.sentonlyemail.utility.ModulePrefs;

public class MainActivity extends AppCompatActivity {

    private ListView email_list;
    private TextView draft_section_header, draft_email_to, draft_email_subject, draft_email_body;
    private LinearLayout draft_email;
    private Button btn_new, btn_latest;

    private ModulePrefs modulePrefs;

    private EmailAdapter emailAdapter;
    private ArrayList<Email> emailArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        emailAdapter = new EmailAdapter(this, emailArrayList);
        email_list.setAdapter(emailAdapter);

        btn_new.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(modulePrefs.getStringPreferences("status").equals("draft"))
                {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Draft email present")
                            .setMessage("By creating a new email, you'll automatically delete the draft. Do you wish to proceed?")
                            // The positive button refers to a "yes, I accept deleted the present draft."
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    // Do what you need to do there
                                    // But remember to move to the new email activity
                                    Intent EditEmailActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.sentonlyemail.EditEmailActivity.class);
                                    EditEmailActivity.putExtras(new Bundle());
                                    startActivity(EditEmailActivity);
                                }
                            })
                            // The positive button refers to a "no, I don't want to delete the draft. Let me stay on the page"
                            // A null listener is used to take no further action and remove the dialog box.
                            .setNegativeButton(android.R.string.no, null)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                } else {
                    Intent EditEmailActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.sentonlyemail.EditEmailActivity.class);
                    EditEmailActivity.putExtras(new Bundle());
                    startActivity(EditEmailActivity);
                }
            }
        });

        btn_latest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emailArrayList.size() > 0) {
                    Intent EmailActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.sentonlyemail.EmailActivity.class);
                    Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                    int lastIndex = emailArrayList.size() - 1;
                    bundle.putString("email_to", emailArrayList.get(lastIndex).getEmail_to());
                    bundle.putString("email_subject", emailArrayList.get(lastIndex).getEmail_subject());
                    bundle.putString("email_body", emailArrayList.get(lastIndex).getEmail_body());
                    EmailActivity.putExtras(bundle);
                    startActivity(EmailActivity);
                } else {
                    Toast.makeText(getApplicationContext(), "Your email list is empty.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        draft_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent EditEmailActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.sentonlyemail.EditEmailActivity.class);
                Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                bundle.putString("email_to", modulePrefs.getStringPreferences("email_to"));
                bundle.putString("email_subject", modulePrefs.getStringPreferences("email_subject"));
                bundle.putString("email_body", modulePrefs.getStringPreferences("email_body"));
                EditEmailActivity.putExtras(bundle);
                startActivity(EditEmailActivity);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
//        Toast.makeText(getApplicationContext(), modulePrefs.getStringPreferences("status"), Toast.LENGTH_SHORT).show();
        switch (modulePrefs.getStringPreferences("status")){
            case "newEmail":
                ((BaseAdapter) email_list.getAdapter()).notifyDataSetChanged();
                draft_section_header.setVisibility(View.GONE);
                draft_email.setVisibility(View.GONE);
                emailArrayList.add(new Email(modulePrefs.getStringPreferences("email_to"), modulePrefs.getStringPreferences("email_subject"), modulePrefs.getStringPreferences("email_body")));
                break;
            case "draft":
                draft_email_to.setText("To: " + (modulePrefs.getStringPreferences("email_to").equals("") ? "<RECEIVER EMAIL>" : modulePrefs.getStringPreferences("email_to")));
                draft_email_subject.setText(modulePrefs.getStringPreferences("email_subject").equals("") ? "<EMAIL SUBJECT>" : modulePrefs.getStringPreferences("email_subject"));
                draft_email_body.setText(modulePrefs.getStringPreferences("email_body").equals("") ? "<BODY OF EMAIL>" : prepareTextForDisplay(modulePrefs.getStringPreferences("email_body")));
                draft_section_header.setVisibility(View.VISIBLE);
                draft_email.setVisibility(View.VISIBLE);
                break;
            case "discarded":
                draft_section_header.setVisibility(View.GONE);
                draft_email.setVisibility(View.GONE);
                break;
            default:
                break;

        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        String emailString = "";

        for (Email email:emailArrayList) {
            emailString += email.getEmail_to() + "," + email.getEmail_subject() + "," + email.getEmail_body() + "#";
        }

        modulePrefs.saveStringPreferences("emailString", emailString);
//        Toast.makeText(this, modulePrefs.getStringPreferences("emailString"), Toast.LENGTH_SHORT).show();
    }

    private void init() {

        modulePrefs = new ModulePrefs(getApplicationContext());

//        Toast.makeText(this, modulePrefs.getStringPreferences("emailString"), Toast.LENGTH_SHORT).show();
        draft_email_to = (TextView) findViewById(R.id.draft_email_to);
        draft_email_subject = (TextView) findViewById(R.id.draft_email_subject);
        draft_email_body = (TextView) findViewById(R.id.draft_email_body);
        draft_section_header = (TextView) findViewById(R.id.draft_section_header);
        draft_email = (LinearLayout) findViewById(R.id.draft_email);

        if(modulePrefs.getStringPreferences("status").equals("draft")){
            draft_email_to.setText("To: " + modulePrefs.getStringPreferences("email_to"));
            draft_email_subject.setText(modulePrefs.getStringPreferences("email_subject"));
            draft_email_body.setText(prepareTextForDisplay(modulePrefs.getStringPreferences("email_body")));
            draft_section_header.setVisibility(View.VISIBLE);
            draft_email.setVisibility(View.VISIBLE);
        } else {
            modulePrefs.saveStringPreferences("status", "appStart");
            draft_section_header.setVisibility(View.GONE);
            draft_email.setVisibility(View.GONE);
        }

        btn_latest = (Button) findViewById(R.id.btn_latest);
        btn_new = (Button) findViewById(R.id.btn_new);

        email_list = (ListView) findViewById(R.id.email_list);

        emailArrayList = new ArrayList<>();
//        emailArrayList.add(new Email("sample@gmail.com", "Sample Subject", "Lorem ipsum dolor sit amet consectetur adipiscing elit."));
//        emailArrayList.add(new Email("sample@gmail.com", "Nunc faucibus mauris in ipsum imperdiet fermentum vitae id enim.", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacinia varius mi, at bibendum felis mattis et. Mauris egestas tincidunt felis, in fermentum metus fermentum sed. Nullam hendrerit erat ut nunc tincidunt, quis molestie metus euismod."));
//        emailArrayList.add(new Email("sample@gmail.com", "Sample Subject", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacinia varius mi, at bibendum felis mattis et. Mauris egestas tincidunt felis, in fermentum metus fermentum sed. Nullam hendrerit erat ut nunc tincidunt, quis molestie metus euismod."));
//        emailArrayList.add(new Email("sample@gmail.com", "Nunc faucibus mauris in ipsum imperdiet fermentum vitae id enim.", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacinia varius mi, at bibendum felis mattis et. Mauris egestas tincidunt felis, in fermentum metus fermentum sed. Nullam hendrerit erat ut nunc tincidunt, quis molestie metus euismod."));
//        emailArrayList.add(new Email("sample@gmail.com", "Sample Subject", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacinia varius mi, at bibendum felis mattis et. Mauris egestas tincidunt felis, in fermentum metus fermentum sed. Nullam hendrerit erat ut nunc tincidunt, quis molestie metus euismod."));
//        emailArrayList.add(new Email("sample@gmail.com", "Latest email", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis lacinia varius mi, at bibendum felis mattis et. Mauris egestas tincidunt felis, in fermentum metus fermentum sed. Nullam hendrerit erat ut nunc tincidunt, quis molestie metus euismod."));

        // CLEAN SAVE PREFS
        if(false){
            modulePrefs.saveStringPreferences("emailString", "");
        }

//        Toast.makeText(this,modulePrefs.getStringPreferences("emailString"), Toast.LENGTH_SHORT).show();

        if(!(modulePrefs.getStringPreferences("emailString").equals(""))) {
            String[] email = modulePrefs.getStringPreferences("emailString").split("#");
//            Toast.makeText(this, email[0], Toast.LENGTH_SHORT).show();

            for (String item:email) {
                String[] splitItem = item.split(",");
//                Toast.makeText(this, splitItem[0], Toast.LENGTH_SHORT).show();
                emailArrayList.add(new Email(splitItem[0], splitItem[1], splitItem[2]));
            }
        }
    }

    private String prepareTextForDisplay(String x) {
        return x.replaceAll("(\\n)+", " ");
    }
}