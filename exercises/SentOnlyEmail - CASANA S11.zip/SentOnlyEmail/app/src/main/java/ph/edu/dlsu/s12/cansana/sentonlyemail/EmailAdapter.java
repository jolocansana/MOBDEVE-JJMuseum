package ph.edu.dlsu.s12.cansana.sentonlyemail;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class EmailAdapter extends ArrayAdapter<Email> {
    private ArrayList<Email> emailArrayList;
    private Activity activity;

    public EmailAdapter (Activity activity, ArrayList<Email> emailArrayList) {
        super(activity, R.layout.email_item, emailArrayList);
        this.activity = activity;
        this.emailArrayList = emailArrayList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if(rowView == null){
            // create the layout
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.email_item, null);

            ViewHolder itemViewHolder = new ViewHolder();
            itemViewHolder.email_to = (TextView) rowView.findViewById(R.id.email_to);
            itemViewHolder.email_subject = (TextView) rowView.findViewById(R.id.email_subject);
            itemViewHolder.email_body = (TextView) rowView.findViewById(R.id.email_body);
            // save the layout in memory
            rowView.setTag(itemViewHolder);
        }

        // Load layout

        final ViewHolder holder = (ViewHolder) rowView.getTag();
        Email info = emailArrayList.get(position);
        holder.email_to.setText("To: " + info.getEmail_to());
        holder.email_subject.setText(info.getEmail_subject());
        holder.email_body.setText(prepareTextForDisplay(info.getEmail_body()));

        return rowView;
    }

    private String prepareTextForDisplay(String x) {
        return x.replaceAll("(\\n)+", " ");
    }

    static class ViewHolder {
        public TextView email_to, email_subject, email_body;
    }
}