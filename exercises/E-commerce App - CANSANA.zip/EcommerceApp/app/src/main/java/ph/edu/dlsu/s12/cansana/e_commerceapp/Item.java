package ph.edu.dlsu.s12.cansana.e_commerceapp;

import java.util.ArrayList;

public class Item {
    private ArrayList<String> imgNames;
    private String product_name, product_category, product_details;


    public Item(ArrayList<String> imgNames, String product_name, String product_category, String product_details) {
        this.imgNames = imgNames;
        this.product_name = product_name;
        this.product_category = product_category;
        this.product_details = product_details;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_category() {
        return product_category;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    public String getProduct_details() {
        return product_details;
    }

    public void setProduct_details(String product_details) {
        this.product_details = product_details;
    }

    public ArrayList<String> getImgNames() {
        return imgNames;
    }

    public void setImgNames(ArrayList<String> imgNames) {
        this.imgNames = imgNames;
    }
}
