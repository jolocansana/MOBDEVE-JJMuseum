package ph.edu.dlsu.s12.cansana.e_commerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class register extends AppCompatActivity {

    private Button btn_submit;

    private EditText username, password, passConfirm;

    private Boolean success;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btn_submit = (Button) findViewById(R.id.btn_submit);

        username = (EditText) findViewById(R.id.username_field);
        password = (EditText) findViewById(R.id.password_field);
        passConfirm = (EditText) findViewById(R.id.confirm_password_field);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (username.getText().toString().length() >= 5) {
                    if (password.getText().toString().length() >= 8){
                        if(password.getText().toString().equals(passConfirm.getText().toString())) {
                            Intent ListActivity = new Intent(getApplicationContext(), List.class);
                            Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                            bundle.putString("username", username.getText().toString());
                            ListActivity.putExtras(bundle);
                            startActivity(ListActivity);
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(),"Passwords do not match", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(),"Password must be at least 8 characters long", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(),"Username must be at least 5 characters long", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}