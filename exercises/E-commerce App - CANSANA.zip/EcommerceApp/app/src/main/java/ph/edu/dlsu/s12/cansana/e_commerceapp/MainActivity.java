package ph.edu.dlsu.s12.cansana.e_commerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btn_login, btn_register;
    private EditText username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = (Button) findViewById(R.id.btn_login);
        btn_register = (Button) findViewById(R.id.btn_register);

        username = (EditText) findViewById(R.id.username_field);
        password = (EditText) findViewById(R.id.password_field);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("admin") && password.getText().toString().equals("admin11235")) {
                    Intent ListActivity = new Intent(getApplicationContext(), List.class);
                    Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                    bundle.putString("username", username.getText().toString());
                    ListActivity.putExtras(bundle);
                    startActivity(ListActivity);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(),"Wrong username and/or password", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent RegisterActivity = new Intent(getApplicationContext(), register.class);
                startActivity(RegisterActivity);
            }
        });
    }
}