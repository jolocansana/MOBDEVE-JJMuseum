package ph.edu.dlsu.s12.cansana.e_commerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Product extends AppCompatActivity {

    private TextView product_name, product_category, product_description;
    private ImageView img_active, img_one, img_two;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        Bundle bundle = getIntent().getExtras();

        product_name = (TextView) findViewById(R.id.product_name);
        product_category = (TextView) findViewById(R.id.product_category);
        product_description = (TextView) findViewById(R.id.product_description);
        img_active = (ImageView) findViewById(R.id.img_active);
        img_one = (ImageView) findViewById(R.id.img_one);
        img_two = (ImageView) findViewById(R.id.img_two);

        product_name.setText(bundle.getString("name"));
        product_category.setText(bundle.getString("category"));
        product_description.setText(bundle.getString("description"));
        img_active.setImageResource(this.getResources().getIdentifier(bundle.getStringArrayList("imgs").get(0),"drawable", this.getApplicationContext().getPackageName()));
        img_one.setImageResource(this.getResources().getIdentifier(bundle.getStringArrayList("imgs").get(0),"drawable", this.getApplicationContext().getPackageName()));
        img_two.setImageResource(this.getResources().getIdentifier(bundle.getStringArrayList("imgs").get(1),"drawable", this.getApplicationContext().getPackageName()));

        img_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_active.setImageResource(getResources().getIdentifier(bundle.getStringArrayList("imgs").get(0),"drawable", getApplicationContext().getPackageName()));
            }
        });

        img_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_active.setImageResource(getResources().getIdentifier(bundle.getStringArrayList("imgs").get(1),"drawable", getApplicationContext().getPackageName()));
            }
        });
    }
}