package ph.edu.dlsu.s12.cansana.e_commerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

public class List extends AppCompatActivity {

    private TextView welcome_message;
    private ListView item_list;

    private ItemAdapter itemAdapter;
    private ArrayList<Item> itemArrayList;

    private Button btn_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        init();

        welcome_message = (TextView) findViewById(R.id.welcome_message);

        Bundle bundle = getIntent().getExtras();
        String username = bundle.getString("username");

        welcome_message.setText("Welcome " + username);

        itemAdapter = new ItemAdapter(this, itemArrayList);
        item_list.setAdapter(itemAdapter);

        item_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent ProductActivity = new Intent(getApplicationContext(), Product.class);
                Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                bundle.putStringArrayList("imgs", itemArrayList.get(position).getImgNames());
                bundle.putString("name", itemArrayList.get(position).getProduct_name());
                bundle.putString("category", itemArrayList.get(position).getProduct_category());
                bundle.putString("description", itemArrayList.get(position).getProduct_details());
                ProductActivity.putExtras(bundle);
                startActivity(ProductActivity);
            }
        });

        btn_logout = (Button) findViewById(R.id.btn_logout);

        btn_logout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent LoginActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(LoginActivity);
                finish();
            }
        });


    }

    private void init() {
        item_list = (ListView) findViewById(R.id.list);

        itemArrayList = new ArrayList<>();

        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("cookie1", "cookie2")), "Choco-chip Cookie", "Food", "Baked Cookies with sugar and chocolate chips"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("mouse1", "mouse2")), "Logitech MX Master 3 Mouse", "Tech", "Logitech MX Master 3 Ergonomic, Bluetooth Wireless Mouse"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("iphone1", "iphone2")), "iPhone 12 Pro Max", "Tech", "Apple iPhone 12 Pro Max 128GB, 5G Enabled, Dual-sim"));
    }

    @Override
    public void onBackPressed() {
        this.finishAffinity();
    }
}