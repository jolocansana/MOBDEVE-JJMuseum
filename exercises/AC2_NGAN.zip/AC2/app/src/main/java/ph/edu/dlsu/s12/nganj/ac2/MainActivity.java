package ph.edu.dlsu.s12.nganj.ac2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

import ph.edu.dlsu.s12.nganj.ac2.adapter.OrderAdapter;
import ph.edu.dlsu.s12.nganj.ac2.model.Order;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Order> orderList;
    private RecyclerView recyclerView;
    private Intent serviceIntent = null;
    private static OrderAdapter orderAdapter;

    private static String[] names = {"Guts", "Casca", "Griffith", "Rickert", "Judeau", "Corkus", "Pippen"};
    private static String[] orderIds = {"100-ROB-421-341", "100-SNY-125-125", "100-ASA-902-734", "100-WOW-101-010"};
    private static String[] itemNames = {"Wonder Machine", "Thingamabob 2000", "Giszo Dizmo", "Behelit necklace fashion smthn"};
    private static String[] itemPrices = {"3499", "139", "250", "500"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        orderList = new ArrayList<>();
        recyclerView = findViewById(R.id.orderRv);

        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        orderAdapter = new OrderAdapter(getApplicationContext(), orderList);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        recyclerView.setAdapter(orderAdapter);

        serviceIntent = new Intent(this, OrderService.class);
        registerService();
        Log.d("Trial", "Done Registering");

    }


    public static void populateArray() {
        Order orderdetails = new Order();

        orderdetails.setName(randomSelectFromData(names));
        orderdetails.setDate(generateDateString());
        orderdetails.setOrderID(randomSelectFromData(orderIds));
        orderdetails.setItemNames(randomSelectFromData(itemNames));
        orderdetails.setItemPrices(randomSelectFromData(itemPrices));

        orderAdapter.addOrder(orderdetails);
    }

    private static String randomSelectFromData(String[] data) {
        int i = new Random().nextInt(data.length);
        return data[i];
    }

    private static String generateDateString() {
        Locale philippineLocale = new Locale.Builder().setLanguage("en").setRegion("PH").build();
        return Calendar.getInstance(philippineLocale).getTime().toString();
    }


    private void registerService(){
        startService(new Intent(this, OrderService.class));
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        stopService(serviceIntent);
    }
}