package ph.edu.dlsu.s12.nganj.ac2.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.ac2.R;
import ph.edu.dlsu.s12.nganj.ac2.ViewOrderActivity;
import ph.edu.dlsu.s12.nganj.ac2.model.Order;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private ArrayList<Order> orderList;
    private Context context;

    public OrderAdapter(Context context, ArrayList<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public void addOrder(Order newOrder) {
        orderList.add(newOrder);
        notifyDataSetChanged();
    }

    @Override
    public OrderAdapter.OrderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.order_row_layout, parent, false);

        OrderViewHolder orderViewHolder = new OrderViewHolder(view);

        return orderViewHolder;
    }

    @Override
    public void onBindViewHolder(final OrderAdapter.OrderViewHolder holder, final int position) {
        holder.name.setText(orderList.get(position).getName());
        holder.date.setText(orderList.get(position).getDate());
        holder.orderID.setText(orderList.get(position).getOrderID());

        holder.viewBtn.setOnClickListener(view -> {
            Intent intent = new Intent(context, ViewOrderActivity.class);
            intent.putExtra("name", orderList.get(position).getName());
            intent.putExtra("date", orderList.get(position).getDate());
            intent.putExtra("orderID", orderList.get(position).getOrderID());
            intent.putExtra("itemName", orderList.get(position).getItemNames());
            intent.putExtra("price", orderList.get(position).getItemPrices());
            context.startActivity(intent);
        });

        holder.pickUpBtn.setOnClickListener(view ->{
            orderList.remove(position);
            notifyDataSetChanged();
        });
    }

    protected class OrderViewHolder extends RecyclerView.ViewHolder {

        private TextView name, date, orderID;
        private Button viewBtn, pickUpBtn;

        public OrderViewHolder(View view) {
            super(view);

            name = view.findViewById(R.id.tv_item);
            date = view.findViewById(R.id.tv_date);
            orderID = view.findViewById(R.id.tv_orderID);
            viewBtn = view.findViewById(R.id.btn_view);
            pickUpBtn = view.findViewById(R.id.btn_pickup);

        }
    }

}
