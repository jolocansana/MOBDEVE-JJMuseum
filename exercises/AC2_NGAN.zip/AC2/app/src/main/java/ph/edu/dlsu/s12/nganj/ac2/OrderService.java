package ph.edu.dlsu.s12.nganj.ac2;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import java.util.Timer;

public class OrderService extends Service {

    private Timer mTimer = null;
    private Handler mHandler = new Handler();
    final int delay = 5000;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Trial", "Service Registered");

        if (mTimer != null)
            mTimer.cancel();
        else
            mTimer = new Timer();

        mHandler.postDelayed(new Runnable() {
            public void run() {

                mHandler.postDelayed(this, delay);
                MainActivity.populateArray();
            }

        }, delay);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        mTimer.cancel();
    }
}
