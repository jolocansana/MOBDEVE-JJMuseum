package ph.edu.dlsu.s12.nganj.ac2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ViewOrderActivity extends AppCompatActivity {

    private TextView Name, Date, OrderID, ItemName, Price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);

        init();

    }

    private void init(){
        Name = findViewById(R.id.tv_viewName);
        Date = findViewById(R.id.tv_viewDate);
        OrderID = findViewById(R.id.tv_viewID);
        ItemName = findViewById(R.id.tv_viewName);
        Price = findViewById(R.id.tv_viewPrice);

        Intent intent = getIntent();
        Name.setText(intent.getStringExtra("name"));
        Date.setText(intent.getStringExtra("date"));
        OrderID.setText(intent.getStringExtra("orderID"));
        ItemName.setText(intent.getStringExtra("itemName"));
        Price.setText(intent.getStringExtra("price"));
    }
}