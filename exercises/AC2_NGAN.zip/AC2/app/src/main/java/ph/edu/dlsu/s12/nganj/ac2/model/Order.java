package ph.edu.dlsu.s12.nganj.ac2.model;

public class Order {

    private String Name, Date, OrderID, ItemNames, ItemPrices;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getOrderID() {
        return OrderID;
    }

    public void setOrderID(String orderID) {
        OrderID = orderID;
    }

    public String getItemNames() {
        return ItemNames;
    }

    public void setItemNames(String itemNames) {
        ItemNames = itemNames;
    }

    public String getItemPrices() {
        return ItemPrices;
    }

    public void setItemPrices(String itemPrices) {
        ItemPrices = itemPrices;
    }
}
