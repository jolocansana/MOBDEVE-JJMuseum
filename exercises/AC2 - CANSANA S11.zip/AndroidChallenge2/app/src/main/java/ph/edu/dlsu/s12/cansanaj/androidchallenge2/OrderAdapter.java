package ph.edu.dlsu.s12.cansanaj.androidchallenge2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {
    private ArrayList<Order> orderArrayList;
    private Context parentContext;

    public OrderAdapter(ArrayList<Order> orderArrayList) {
        this.orderArrayList = orderArrayList;
    }

    @Override
    public OrderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);

        OrderViewHolder orderViewHolder = new OrderViewHolder(view);
        parentContext = parent.getContext();

        return orderViewHolder;
    }

    @Override
    public void onBindViewHolder(final OrderViewHolder holder, int position) {
        holder.viewOrderNameTv.setText(orderArrayList.get(position).getOrderName());
        holder.viewOrderDateTv.setText(orderArrayList.get(position).getOrderDate());
        holder.viewOrderIdTv.setText(orderArrayList.get(position).getOrderID());

        holder.viewOrderListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewOrderActivity = new Intent(parentContext, ViewOrderActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("ID", orderArrayList.get(position).getOrderID());
                bundle.putString("Name", orderArrayList.get(position).getOrderName());
                bundle.putString("Date", orderArrayList.get(position).getOrderDate());
                bundle.putString("Item", orderArrayList.get(position).getOrderItem());
                bundle.putString("Price", orderArrayList.get(position).getOrderPrice());
                viewOrderActivity.putExtras(bundle);
                parentContext.startActivity(viewOrderActivity);
            }
        });

        holder.pickUpDriverBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                orderArrayList.remove(position);
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderArrayList.size();
    }

    protected class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView viewOrderNameTv, viewOrderDateTv, viewOrderIdTv;
        Button viewOrderListBtn, pickUpDriverBtn;

        public OrderViewHolder(View view) {
            super(view);

            viewOrderNameTv = view.findViewById(R.id.viewOrderNameTv);
            viewOrderDateTv = view.findViewById(R.id.viewOrderDateTv);
            viewOrderIdTv = view.findViewById(R.id.viewOrderIdTv);

            viewOrderListBtn = view.findViewById(R.id.viewOrderListBtn);
            pickUpDriverBtn = view.findViewById(R.id.pickUpDriverBtn);
        }

    }
}
