package ph.edu.dlsu.s12.cansanaj.androidchallenge2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = "TEST";
    private RecyclerView orderListRv;
    protected ArrayList<Order> orderArrayList;
    private OrderAdapter orderAdapter;
    private BroadcastReceiver broadcastReceiver = new OrderBroadcastReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "onCreate: ");
        startService(new Intent(this, OrderService.class));

        IntentFilter filter = new IntentFilter();

        filter.addAction("ph.edu.dlsu.s12.cansanaj.ORDER_JOB");

        registerReceiver(broadcastReceiver, filter);

        init();

//        populateList();

        orderListRv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        orderAdapter = new OrderAdapter(orderArrayList);
        orderListRv.setAdapter(orderAdapter);
    }

    private void init () {
        orderListRv = findViewById(R.id.orderListRv);

        orderArrayList = new ArrayList<>();
    }

    public class OrderBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            Log.d(TAG, "onReceive: " + bundle.get("ID"));
            orderArrayList.add(0, new Order(bundle.get("ID").toString(), bundle.get("orderName").toString(), bundle.get("orderDate").toString(), bundle.get("orderItem").toString(), bundle.get("orderPrice").toString()));
            orderAdapter.notifyDataSetChanged();
        }
    }


//    Used for checking if adapter is working
//    private void populateList() {
//        orderArrayList.add(new Order("ID1", "Name", "Date", "Item", "Price"));
//        orderArrayList.add(new Order("ID2", "Name", "Date", "Item", "Price"));
//        orderArrayList.add(new Order("ID3", "Name", "Date", "Item", "Price"));
//    }
}