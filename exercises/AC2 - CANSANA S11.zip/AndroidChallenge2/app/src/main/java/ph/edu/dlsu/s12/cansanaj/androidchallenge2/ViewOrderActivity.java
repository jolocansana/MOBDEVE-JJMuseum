package ph.edu.dlsu.s12.cansanaj.androidchallenge2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ViewOrderActivity extends AppCompatActivity {

    private TextView viewOrderIdTv, viewOrdererNameTv, viewDateTv, viewItemNameTv, viewItemPriceTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_order);

        init();

        Bundle bundle = getIntent().getExtras();

        viewOrderIdTv.setText("Order ID: " + bundle.getString("ID"));
        viewOrdererNameTv.setText("Orderer's Name: " + bundle.getString("Name"));
        viewDateTv.setText("Ordered on: " + bundle.getString("Date"));
        viewItemNameTv.setText("Item: " + bundle.getString("Item"));
        viewItemPriceTv.setText("Price: " + bundle.getString("Price"));
    }

    private void init() {
        viewOrderIdTv = findViewById(R.id.viewOrderIdTv);
        viewOrdererNameTv = findViewById(R.id.viewOrdererNameTv);
        viewDateTv = findViewById(R.id.viewDateTv);
        viewItemNameTv = findViewById(R.id.viewItemNameTv);
        viewItemPriceTv = findViewById(R.id.viewItemPriceTv);
    }
}