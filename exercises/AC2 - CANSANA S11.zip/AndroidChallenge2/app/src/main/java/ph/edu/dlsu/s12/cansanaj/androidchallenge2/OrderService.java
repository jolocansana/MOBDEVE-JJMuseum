package ph.edu.dlsu.s12.cansanaj.androidchallenge2;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;

import java.util.Calendar;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class OrderService extends Service {
    private static final String TAG = "ORDERSERVICE";
    public static final int notify = 2000;
    private Handler mHandler = new Handler();
    private Timer mTimer = null;
    private MainActivity mainActivity;
    private Random random;

    private String[] names = {"Guts", "Casca", "Griffith", "Rickert", "Judeau", "Corkus", "Pippen"};
    private String[] orderIds = {"100-ROB-421-341", "100-SNY-125-125", "100-ASA-902-734", "100-WOW-101-010"};
    private String[] itemNames = {"Wonder Machine", "Thingamabob 2000", "Giszo Dizmo", "Behelit necklace fashion smthn"};
    private String[] itemPrices = {"3499", "139", "250", "500"};

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        if (mTimer != null)
            mTimer.cancel();
        else
            mTimer = new Timer();
        random = new Random();
        mTimer.scheduleAtFixedRate(new TimeDisplay(), 0, notify);   //Schedule task
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mTimer.cancel();
    }

    private String randomSelectFromData(String[] data) {
        return data[this.random.nextInt(data.length)];
    }

    private String generateDateString() {
        Locale philippineLocale = new Locale.Builder().setLanguage("en").setRegion("PH").build();
        return Calendar.getInstance(philippineLocale).getTime().toString();
    }

    class TimeDisplay extends TimerTask {
        @Override
        public void run() {
            // run on another thread
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep((4+random.nextInt(2))*1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putString("ID", randomSelectFromData(orderIds));
                    bundle.putString("orderName", randomSelectFromData(names));
                    bundle.putString("orderDate", generateDateString());
                    bundle.putString("orderItem", randomSelectFromData(itemNames));
                    bundle.putString("orderPrice", randomSelectFromData(itemPrices));
                    intent.putExtras(bundle);
                    intent.setAction("ph.edu.dlsu.s12.cansanaj.ORDER_JOB");
                    sendBroadcast(intent);
                }
            });
        }
    }
}
