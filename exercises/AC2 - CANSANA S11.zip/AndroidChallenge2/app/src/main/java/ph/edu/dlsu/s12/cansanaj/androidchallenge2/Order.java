package ph.edu.dlsu.s12.cansanaj.androidchallenge2;

public class Order {
    private String orderID, orderName, orderDate, orderItem, orderPrice;

    public Order(String orderID, String orderName, String orderDate, String orderItem, String orderPrice) {
        this.orderID = orderID;
        this.orderName = orderName;
        this.orderDate = orderDate;
        this.orderItem = orderItem;
        this.orderPrice = orderPrice;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(String orderItem) {
        this.orderItem = orderItem;
    }

    public String getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(String orderPrice) {
        this.orderPrice = orderPrice;
    }
}
