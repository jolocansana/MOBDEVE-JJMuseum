package ph.edu.dlsu.s12.cansanaj.orderlistapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansanaj.orderlistapp.adapter.OrderListAdapter;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.model.Item;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.model.OrderList;

import static java.lang.String.valueOf;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rv_list;
    private static ArrayList<OrderList> orderList;
    private OrderListAdapter orderListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        populateList();
        init();

        orderListAdapter = new OrderListAdapter(orderList);
        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rv_list.setAdapter(orderListAdapter);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(rv_list);
    }

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            orderListAdapter.removeItem(viewHolder.getAdapterPosition());
//            Log.d("REMOVED, CURR TOP: ", orderList.get(0).getVendor());
        }
    };

    public static OrderList getOrderList(String order_id) {
        for (OrderList item : orderList) {
            if(item.getOrderID().equals(order_id)){
                Log.d("ITEM FOUND", item.getVendor());
                return item;
            }
        }
        return null;
    }

    private void init() {
        rv_list = (RecyclerView) findViewById(R.id.rv_list);
    }

    private void populateList(){
        orderList = new ArrayList<>();
        OrderList sample = new OrderList();

        sample.setDate("May 1, 2021");
        sample.setVendor("iStore");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-AAA-000-001");
        sample.addItem(new Item("IPhone 12", 60000.00f, 1));
        orderList.add(0, sample);

        sample.setDate("May 1, 2021");
        sample.setVendor("Huawei");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-HWI-999-998");
        sample.addItem(new Item("Mate 40 Pro", 60000.00f, 1));
        orderList.add(0, sample);

        sample.setDate("May 1, 2021");
        sample.setVendor("Sony");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-SNY-125-125");
        sample.addItem(new Item("Playstation 5", 28000.00f, 1));
        sample.addItem(new Item("Playstation 5 Controller", 2800.00f, 1));
        sample.addItem(new Item("Playstation 5 Game", 2800.00f, 1));
        sample.addItem(new Item("Playstation 5 Game", 2800.00f, 1));
        sample.addItem(new Item("Playstation 5 Game", 0.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 2, 2021");
        sample.setVendor("El Pollo Loco");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-ASD-322-552");
        sample.addItem(new Item("Fried Chicken", 600.00f, 1));
        sample.addItem(new Item("El Pollo Loco Special", 600.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 2, 2021");
        sample.setVendor("Sbarro");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-SBO-747-888");
        sample.addItem(new Item("Zitti Half White Sauce", 90.00f, 1));
        sample.addItem(new Item("California Deep Dish Pizza", 240.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 2, 2021");
        sample.setVendor("Jollibee");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-JBE-747-888");
        sample.addItem(new Item("Chickenjoy Meal", 120.00f, 1));
        sample.addItem(new Item("Burgersteak Meal", 70.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 3, 2021");
        sample.setVendor("Mexicali");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-USD-556-633");
        sample.addItem(new Item("French Fries", 240.00f, 1));
        sample.addItem(new Item("French Toast", 400.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 3, 2021");
        sample.setVendor("KFC");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-KFC-999-111");
        sample.addItem(new Item("Fried Chicken Solo", 140.00f, 1));
        sample.addItem(new Item("Brownies", 40.00f, 1));
        sample.addItem(new Item("Mac 'n Cheese", 40.00f, 1));
        sample.addItem(new Item("Iced Tea", 40.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 3, 2021");
        sample.setVendor("McDonald");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-GDP-876-901");
        sample.addItem(new Item("Big Mac Meal", 180.00f, 1));
        sample.addItem(new Item("Cheese Burger Meal", 120.00f, 1));
        sample.addItem(new Item("McSpaghetti", 90.00f, 1));
        sample.addItem(new Item("Choco Sundae", 40.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 4, 2021");
        sample.setVendor("Anne's Pastries");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-ANP-971-888");
        sample.addItem(new Item("Burnt Cheese Cake", 600.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 4, 2021");
        sample.setVendor("PizzaNelli's Neopolitan Pizza");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-ASA-902-734");
        sample.addItem(new Item("Shrimp Scampi", 600.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 4, 2021");
        sample.setVendor("iStore");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-AAA-000-255");
        sample.addItem(new Item("Macbook Pro", 100000.00f, 1));
        orderList.add(0, sample);

        sample = new OrderList();
        sample.setDate("May 5, 2021");
        sample.setVendor("Robinsons Grocery");
        sample.setDeliveryPerson("10114246");
        sample.setOrderId("100-ROB-421-341");
        sample.addItem(new Item("Milk", 80.00f, 1));
        sample.addItem(new Item("Yogurt Drink : Mixed Berry", 18.00f,24 ));
        sample.addItem(new Item("Yogurt Drink : StrawBerry", 18.00f,24 ));
        sample.addItem(new Item("Yogurt Drink : RaspBerry", 18.00f,24 ));
        sample.addItem(new Item("500g Chicken", 140.00f,1 ));
        sample.addItem(new Item("500g Bacon", 240.00f,1 ));
        sample.addItem(new Item("Paper Towel", 180.00f,1 ));
        sample.addItem(new Item("Soap", 50.00f,10 ));
        sample.addItem(new Item("Shampoo", 560.00f,1 ));
        sample.addItem(new Item("DishWashing Soap", 120.00f,1 ));
        sample.addItem(new Item("1KG Melon", 240.00f,1 ));
        sample.addItem(new Item("1KG Apple", 240.00f,1 ));
        sample.addItem(new Item("1KG Banana", 160.00f,1 ));
        sample.addItem(new Item("1KG Potato", 150.00f,1 ));
        sample.addItem(new Item("1KG Carrot", 160.00f,1 ));
        sample.addItem(new Item("Ham", 200.00f,1 ));
        sample.addItem(new Item("Embotido 200g", 250.00f,5 ));
        orderList.add(0, sample);
    }
}