package ph.edu.dlsu.s12.cansanaj.orderlistapp.model;

public class Item {
    private String item_name;
    private float item_cost;
    private int item_quantity;

    public Item(String item_name, float item_cost, int item_quantity) {
        this.item_name = item_name;
        this.item_cost = item_cost;
        this.item_quantity = item_quantity;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public float getItem_cost() {
        return item_cost;
    }

    public void setItem_cost(float item_cost) {
        this.item_cost = item_cost;
    }

    public int getItem_quantity() {
        return item_quantity;
    }

    public void setItem_quantity(int item_quantity) {
        this.item_quantity = item_quantity;
    }
}
