package ph.edu.dlsu.s12.cansanaj.orderlistapp.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


import ph.edu.dlsu.s12.cansanaj.orderlistapp.R;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.model.Item;

import static java.lang.String.valueOf;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.PurchaseListViewHolder> {
    private ArrayList<Item> purchaseListArrayList;

    public ItemListAdapter(ArrayList<Item> purchaseListArrayList) {
        this.purchaseListArrayList = purchaseListArrayList;
    }


    @Override
    public ItemListAdapter.PurchaseListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_view, parent, false);

        ItemListAdapter.PurchaseListViewHolder purchaseListViewHolder = new ItemListAdapter.PurchaseListViewHolder(view);

        return purchaseListViewHolder;
    }

    @Override
    public void onBindViewHolder(final ItemListAdapter.PurchaseListViewHolder holder, int position) {
        Log.d("ITEM ARRAY", purchaseListArrayList.get(position).getItem_name());
        holder.tv_item_name.setText("Name: " + purchaseListArrayList.get(position).getItem_name());
        holder.tv_item_quantity.setText("Quantity: " + valueOf(purchaseListArrayList.get(position).getItem_quantity()));
        holder.tv_item_cost.setText("Cost: " + valueOf(purchaseListArrayList.get(position).getItem_cost()));
    }

    @Override
    public int getItemCount() {
        return purchaseListArrayList.size();
    }



    protected class PurchaseListViewHolder extends RecyclerView.ViewHolder {
        TextView tv_item_name, tv_item_quantity, tv_item_cost;

        public PurchaseListViewHolder(View view){
            super(view);

            tv_item_name = view.findViewById(R.id.tv_item_name);
            tv_item_quantity = view.findViewById(R.id.tv_item_quantity);
            tv_item_cost = view.findViewById(R.id.tv_item_cost);
        }
    }
}
