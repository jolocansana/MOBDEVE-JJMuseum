package ph.edu.dlsu.s12.cansanaj.orderlistapp.model;

import java.util.ArrayList;

public class OrderList {
    private String vendor, date, orderId, deliveryPerson;
    private ArrayList<Item> itemArrayList;

    public OrderList() {
        itemArrayList = new ArrayList<>();
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOrderID() {
        return orderId;
    }

    public void setOrderId(String orderID) {
        this.orderId = orderID;
    }

    public String getDeliveryPerson() {
        return deliveryPerson;
    }

    public void setDeliveryPerson(String deliveryPerson) {
        this.deliveryPerson = deliveryPerson;
    }

    public ArrayList<Item> getItemArrayList() {
        return itemArrayList;
    }

    public void setItemArrayList(ArrayList<Item> itemArrayList) {
        this.itemArrayList = itemArrayList;
    }

    public void addItem(Item item) {
        this.itemArrayList.add(item);
    }
}
