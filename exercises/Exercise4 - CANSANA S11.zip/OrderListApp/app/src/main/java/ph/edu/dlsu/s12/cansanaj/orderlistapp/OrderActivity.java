package ph.edu.dlsu.s12.cansanaj.orderlistapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import ph.edu.dlsu.s12.cansanaj.orderlistapp.adapter.ItemListAdapter;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.model.OrderList;

public class OrderActivity extends AppCompatActivity {

    private ItemListAdapter itemListAdapter;
    private OrderList orderList;
    private RecyclerView rv_list;
    private TextView tv_store, tv_date, tv_orderid, tv_courierid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        init();

        tv_store.setText(orderList.getVendor());
        tv_date.setText(orderList.getDate());
        tv_orderid.setText(orderList.getOrderID());
        tv_courierid.setText(orderList.getDeliveryPerson());

        itemListAdapter = new ItemListAdapter(orderList.getItemArrayList());
        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        rv_list.setAdapter(itemListAdapter);
    }

    private void init() {
        Bundle bundle = getIntent().getExtras();
        String orderID = bundle.getString("order_id");

        orderList = MainActivity.getOrderList(orderID);

        tv_store = (TextView) findViewById(R.id.tv_store);
        tv_date = (TextView) findViewById(R.id.tv_date);
        tv_orderid = (TextView) findViewById(R.id.tv_orderid);
        tv_courierid = (TextView) findViewById(R.id.tv_courierid);
        rv_list = (RecyclerView) findViewById(R.id.rv_list);

    }
}