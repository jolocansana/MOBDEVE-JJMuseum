package ph.edu.dlsu.s12.cansanaj.orderlistapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansanaj.orderlistapp.OrderActivity;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.R;
import ph.edu.dlsu.s12.cansanaj.orderlistapp.model.OrderList;

public class OrderListAdapter extends RecyclerView.Adapter<OrderListAdapter.OrderListViewHolder> {

    private ArrayList<OrderList> orderListArrayList;

    public OrderListAdapter(ArrayList<OrderList> orderListArrayList) {
        this.orderListArrayList = orderListArrayList;
    }


    @Override
    public OrderListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_purchase_view, parent, false);

        OrderListViewHolder orderViewHolder = new OrderListViewHolder(view);

        return orderViewHolder;
    }

    @Override
    public void onBindViewHolder(final OrderListViewHolder holder, int position) {
        holder.tv_store.setText(orderListArrayList.get(position).getVendor());
        holder.tv_date.setText(orderListArrayList.get(position).getDate());
        holder.tv_orderid.setText(orderListArrayList.get(position).getOrderID());
        holder.tv_courierid.setText(orderListArrayList.get(position).getDeliveryPerson());

        holder.btn_view_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, OrderActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("order_id", orderListArrayList.get(position).getOrderID());
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderListArrayList.size();
    }

    public void removeItem(int position) {
        this.orderListArrayList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, getItemCount() - position);
    }


    protected class OrderListViewHolder extends RecyclerView.ViewHolder {
        TextView tv_store, tv_date, tv_orderid, tv_courierid;
        Button btn_view_details;

        public OrderListViewHolder(View view){
            super(view);

            tv_store = view.findViewById(R.id.tv_store);
            tv_date = view.findViewById(R.id.tv_date);
            tv_orderid = view.findViewById(R.id.tv_orderid);
            tv_courierid = view.findViewById(R.id.tv_courierid);

            btn_view_details = view.findViewById(R.id.btn_view_details);
        }
    }
}
