package ph.edu.dlsu.s12.cansana.sentonlyemail;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ph.edu.dlsu.s12.cansana.sentonlyemail.utility.ModulePrefs;

public class EditEmailActivity extends AppCompatActivity {

    private Button btn_discard, btn_send;
    private ModulePrefs modulePrefs;
    private EditText email_to_field, email_subject_field, email_body_field;
    private Bundle bundle;
    private boolean isLegalFinish = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_email);

        init();

        if(!bundle.isEmpty()) {
            email_to_field.setText(bundle.getString("email_to"));
            email_subject_field.setText(bundle.getString("email_subject"));
            email_body_field.setText(bundle.getString("email_body"));
        }

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(email_to_field.getText().toString().length() > 1 && email_subject_field.getText().toString().length() > 1 && email_body_field.getText().toString().length() > 1)
                {
                    modulePrefs.saveStringPreferences("status", "newEmail");
                    modulePrefs.saveStringPreferences("email_to", email_to_field.getText().toString());
                    modulePrefs.saveStringPreferences("email_subject", email_subject_field.getText().toString());
                    modulePrefs.saveStringPreferences("email_body", email_body_field.getText().toString());
                    isLegalFinish = true;
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Please make sure all entries have text.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_discard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modulePrefs.saveStringPreferences("status", "discarded");
                isLegalFinish = true;
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if(email_to_field.getText().toString().length() > 1 || email_subject_field.getText().toString().length() > 1 || email_body_field.getText().toString().length() > 1)
        {
            modulePrefs.saveStringPreferences("status", "draft");
            modulePrefs.saveStringPreferences("email_to", email_to_field.getText().toString().length() > 1 ? email_to_field.getText().toString() : "");
            modulePrefs.saveStringPreferences("email_subject", email_subject_field.getText().toString().length() > 1 ? email_subject_field.getText().toString() : "");
            modulePrefs.saveStringPreferences("email_body", email_body_field.getText().toString().length() > 1 ? email_body_field.getText().toString() : "");
            finish();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if(!isLegalFinish && (email_to_field.getText().toString().length() > 1 || email_subject_field.getText().toString().length() > 1 || email_body_field.getText().toString().length() > 1))
        {
            modulePrefs.saveStringPreferences("status", "draft");
            modulePrefs.saveStringPreferences("email_to", email_to_field.getText().toString().length() > 1 ? email_to_field.getText().toString() : "");
            modulePrefs.saveStringPreferences("email_subject", email_subject_field.getText().toString().length() > 1 ? email_subject_field.getText().toString() : "");
            modulePrefs.saveStringPreferences("email_body", email_body_field.getText().toString().length() > 1 ? email_body_field.getText().toString() : "");
            finish();
        }
    }

    private void init() {

        modulePrefs = new ModulePrefs(getApplicationContext());

        bundle = getIntent().getExtras();

        btn_discard = (Button) findViewById(R.id.btn_discard);
        btn_send = (Button) findViewById(R.id.btn_send);

        email_to_field = (EditText) findViewById(R.id.email_to_field);
        email_subject_field = (EditText) findViewById(R.id.email_subject_field);
        email_body_field  = (EditText) findViewById(R.id.email_body_field);

    }
}