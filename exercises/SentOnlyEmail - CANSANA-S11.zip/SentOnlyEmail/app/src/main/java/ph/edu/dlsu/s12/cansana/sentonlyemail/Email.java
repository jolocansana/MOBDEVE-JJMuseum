package ph.edu.dlsu.s12.cansana.sentonlyemail;

import java.util.ArrayList;

public class Email {
    private String email_to, email_subject, email_body;

    public Email(String email_to, String email_subject, String email_body) {
        this.email_to = email_to;
        this.email_subject = email_subject;
        this.email_body = email_body;
    }

    public String getEmail_to() {
        return email_to;
    }

    public void setEmail_to(String email_to) {
        this.email_to = email_to;
    }

    public String getEmail_subject() {
        return email_subject;
    }

    public void setEmail_subject(String email_subject) {
        this.email_subject = email_subject;
    }

    public String getEmail_body() {
        return email_body;
    }

    public void setEmail_body(String email_body) {
        this.email_body = email_body;
    }
}
