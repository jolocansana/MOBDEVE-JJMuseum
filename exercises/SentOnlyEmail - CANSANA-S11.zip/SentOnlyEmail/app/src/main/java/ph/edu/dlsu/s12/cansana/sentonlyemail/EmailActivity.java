package ph.edu.dlsu.s12.cansana.sentonlyemail;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import ph.edu.dlsu.s12.cansana.sentonlyemail.utility.ModulePrefs;

public class EmailActivity extends AppCompatActivity {

    // Views needed
    private TextView senderTv, receiverTv, subjectTv, bodyTv;
    private ModulePrefs modulePrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        // Initialization of the views
        this.senderTv = findViewById(R.id.emailSenderTv);
        this.receiverTv = findViewById(R.id.emailReceiverTv);
        this.subjectTv = findViewById(R.id.emailSubjectTv);
        this.bodyTv = findViewById(R.id.emailBodyTv);

        // Get intent data
        Bundle bundle = getIntent().getExtras();
        String sender = "From: me";
        String receiver = bundle.getString("email_to");
        String subject = bundle.getString("email_subject");
        String body = bundle.getString("email_body");

        // Set Text attributes of all views
        this.senderTv.setText(sender);
        this.receiverTv.setText("To: " + receiver);
        this.subjectTv.setText(subject);
        this.bodyTv.setText(body);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        modulePrefs = new ModulePrefs(getApplicationContext());
        modulePrefs.saveStringPreferences("status", "viewEmail");
        finish();
    }
}