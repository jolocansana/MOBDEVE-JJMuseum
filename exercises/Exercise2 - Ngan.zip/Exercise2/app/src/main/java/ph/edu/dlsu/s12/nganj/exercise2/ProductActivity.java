package ph.edu.dlsu.s12.nganj.exercise2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;


public class ProductActivity extends AppCompatActivity {

    private TextView productNameTv;
    private TextView productPriceTv;
    private ImageView productIv;
    private Button addBtn, minusBtn;
    private Button removeBtn, updateBtn;
    private TextView countTv;
    private int count;
    private float price;
    private float updatedprice;
    private static DecimalFormat df = new DecimalFormat("0.00");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

       // modulePrefs = new ModulePrefs(getApplicationContext());
        init();

        Bundle bundle =  getIntent().getExtras();
        String prod_name = bundle.getString("productNameTv");
        String prod_desc = bundle.getString("productDescTv");
        String prod_price = bundle.getString("productPriceTv");
        price = Float.parseFloat(prod_price);
        String from = bundle.getString("fromBoolean");
        int prod_image = bundle.getInt("productIv");

        productIv.setImageResource(prod_image);
        productNameTv.setText(prod_name);
        productPriceTv.setText(prod_price);

        if (from.equals("main")){
            removeBtn.setVisibility(View.GONE);
            updateBtn.setText("Add to Basket - " + prod_price);
        }

        if(from.equals("cart")){
            removeBtn.setVisibility(View.VISIBLE);
            updateBtn.setText("Update Basket - " + prod_price);
        }


        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                countTv.setText(String.valueOf(count));

                updatedprice = price * count ;

                updateBtn.setText("Add to Basket - " + df.format(updatedprice));
            }
        });

        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count <= 1){

                }else{
                    count--;
                    countTv.setText(String.valueOf(count));
                }

                updatedprice = price * count ;
                updateBtn.setText("Add to Basket - " + df.format(updatedprice));
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (count == 1){updatedprice = price;}

                String strprice = String.valueOf(updatedprice);

                Intent intent = new Intent(ProductActivity.this, CartActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", prod_name);
                bundle.putString("productDescTv", prod_desc);
                bundle.putString("productPriceTv", strprice);
                bundle.putInt("productImg", prod_image);
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.funko);
                startActivity(intent);
            }
        });

    }

    private void init(){
        productIv = (ImageView)findViewById(R.id.productIv);
        productNameTv = (TextView)findViewById(R.id.productNameTv);
        productPriceTv = (TextView)findViewById(R.id.productPriceTv);

        addBtn = (Button)findViewById(R.id.plusBtn);
        minusBtn = (Button)findViewById(R.id.minusBtn);
        countTv = (TextView)findViewById(R.id.countTv);
        count = Integer.parseInt(countTv.getText().toString());
        removeBtn = (Button)findViewById(R.id.removeBtn);
        updateBtn = (Button)findViewById(R.id.updateBtn);
    }


}