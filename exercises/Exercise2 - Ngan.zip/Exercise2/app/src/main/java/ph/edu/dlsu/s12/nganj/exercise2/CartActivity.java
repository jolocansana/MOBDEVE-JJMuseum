package ph.edu.dlsu.s12.nganj.exercise2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.exercise2.utility.ModulePrefs;

public class CartActivity extends AppCompatActivity {

    private ListView cartList;
    private CartAdapter cartAdapter;
    private ArrayList<Cart> cartArrayList;
    private ImageView productIv;
    private TextView productNameTv, productPriceTv, totalPriceTv;
    private float price = 0, totalprice = 0;
    private Button placeBtn, backBtn;
    private static DecimalFormat df = new DecimalFormat("0.00");
    private ModulePrefs modulePrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        modulePrefs = new ModulePrefs(getApplicationContext());

        init();

        Bundle bundle = getIntent().getExtras();
        String prod_name = bundle.getString("productNameTv");
        String prod_desc = bundle.getString("productDescTv");
        String prod_price = bundle.getString("productPriceTv");
        Drawable prod_image = getDrawable(bundle.getInt("productIv"));
        //int prod_image = bundle.getInt("productIv");

        cartAdapter = new CartAdapter(this, cartArrayList);
        cartList.setAdapter(cartAdapter);

        Cart newCart = new Cart();
        newCart.setName(prod_name);
        newCart.setDesc(prod_desc);
        newCart.setPrice(prod_price);
        newCart.setImage(prod_image);

        cartAdapter.addCart(newCart);

        price = Integer.parseInt(prod_price);
        totalprice += price;

/*
        String[] cartItems = cart.split("\n");
        for(int index = 0; index < cartItems.length; index++){
            String[] itemInfo = cartItems[index].split(",");
            System.out.println("[" + index + "] " + cartItems[index]);

            for(int fieldIndex = 0; fieldIndex < itemInfo.length; fieldIndex++){
                System.out.println("[" + index + "] " + fieldIndex + " : " + itemInfo[fieldIndex]);
            }
        }
*/
        /*totalPriceTv += all prices in array
          totalPriceTv.setText(""+ df.format(totalprice));*/

        price = Integer.parseInt(prod_price);
        totalPriceTv.setText(""+ df.format(price));

        /*cartArrayList[i].setOnClickListener(new View.OnClickListener(){
        * Intent intent = new Intent(CartActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", prod_name);
                bundle.putString("productDescTv", prod_desc);
                bundle.putString("productPriceTv", strprice);
                bundle.putInt("productImg", prod_image);
                intent.putExtras(bundle);
                bundle.putString("fromBoolean", "cart");
                startActivity(intent);*/

        placeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //cartArrayList.clear();
                totalPriceTv.setText("0.00");
                //removes all item in the cart, to simulate purchasing the order
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CartActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void init() {
        productIv = (ImageView) findViewById(R.id.productIv);
        productNameTv = (TextView) findViewById(R.id.productNameTv);
        productPriceTv = (TextView) findViewById(R.id.productPriceTv);
        totalPriceTv = (TextView)findViewById(R.id.totalPriceTv);

        //cartArrayList = new ArrayList<>();

        placeBtn = (Button)findViewById(R.id.placeBtn);
        backBtn = (Button)findViewById(R.id.backBtn);
/*
        //Trial
        Cart cart= new Cart();
        cart.setName("Product 1");
        cart.setDesc("ippsum");
        cart.setPrice("100.00");
        cart.setImage(R.drawable.funko);
        cartArrayList.add(cart);
*/
    }

    @Override
    protected void onPause(){
        super.onPause();
        /*
        String[] cartItems = cartArrayList.split("\n");
        for(int index = 0; index < cartItems.length; index++){
            String[] itemInfo = cartItems[index].split(",");

            modulePrefs.saveStringPreferences("input",prod_name.getText().toString());
            modulePrefs.saveStringPreferences("input",prod_desc.getText().toString());
            modulePrefs.saveStringPreferences("input",prod_price.getText().toString());
        */

    }
}
