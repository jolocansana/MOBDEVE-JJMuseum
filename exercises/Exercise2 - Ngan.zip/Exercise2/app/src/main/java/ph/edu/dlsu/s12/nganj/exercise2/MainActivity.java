package ph.edu.dlsu.s12.nganj.exercise2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    ImageView img1, img2, img3, img4, img5;
    TextView name1, name2, name3, name4, name5;
    TextView desc1, desc2, desc3, desc4, desc5;
    TextView price1, price2, price3, price4, price5;
    private TextView productname;
    private TextView productprice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

    }

    private void init(){

        View myLayout1 = findViewById( R.id.item01 );
        img1 = (ImageView)myLayout1.findViewById(R.id.productImg);
        name1 = (TextView)myLayout1.findViewById(R.id.productName);
        desc1 = (TextView)myLayout1.findViewById(R.id.productDesc);
        price1 = (TextView)myLayout1.findViewById(R.id.productPrice);
        img1.setImageResource(R.drawable.funko);
        name1.setText("Funko 13 Edition");
        desc1.setText("Lorem Ipsum111");
        price1.setText("100.00");

        View myLayout2 = findViewById( R.id.item02 );
        img2 = (ImageView)myLayout2.findViewById(R.id.productImg);
        name2 = (TextView)myLayout2.findViewById(R.id.productName);
        desc2 = (TextView)myLayout2.findViewById(R.id.productDesc);
        price2 = (TextView)myLayout2.findViewById(R.id.productPrice);
        img2.setImageResource(R.drawable.funko2);
        name2.setText("Funko 25 Edition");
        desc2.setText("Lorem Ipsum222");
        price2.setText("200.00");

        View myLayout3 = findViewById( R.id.item03 );
        img3 = (ImageView)myLayout3.findViewById(R.id.productImg);
        name3 = (TextView)myLayout3.findViewById(R.id.productName);
        desc3 = (TextView)myLayout3.findViewById(R.id.productDesc);
        price3 = (TextView)myLayout3.findViewById(R.id.productPrice);
        img3.setImageResource(R.drawable.jacket1);
        name3.setText("Jacket 333#");
        desc3.setText("Lorem Ipsum333");
        price3.setText("300.00");

        View myLayout4 = findViewById( R.id.item04 );
        img4 = (ImageView)myLayout4.findViewById(R.id.productImg);
        name4 = (TextView)myLayout4.findViewById(R.id.productName);
        desc4 = (TextView)myLayout4.findViewById(R.id.productDesc);
        price4 = (TextView)myLayout4.findViewById(R.id.productPrice);
        img4.setImageResource(R.drawable.jacket2);
        name4.setText("Jacket 777#");
        desc4.setText("Lorem Ipsum444");
        price4.setText("400.00");

        View myLayout5 = findViewById( R.id.item05 );
        img5 = (ImageView)myLayout5.findViewById(R.id.productImg);
        name5 = (TextView)myLayout5.findViewById(R.id.productName);
        desc5 = (TextView)myLayout5.findViewById(R.id.productDesc);
        price5 = (TextView)myLayout5.findViewById(R.id.productPrice);
        img5.setImageResource(R.drawable.shirt2);
        name5.setText("League Shirt");
        desc5.setText("Lorem Ipsum555");
        price5.setText("500.00");

        myLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", name1.getText().toString());
                bundle.putString("productPriceTv", price1.getText().toString());
                bundle.putString("fromBoolean", "main");
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.funko);
                startActivity(intent);
            }
        });

        myLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", name2.getText().toString());
                bundle.putString("productPriceTv", price2.getText().toString());
                bundle.putString("fromBoolean", "main");
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.funko2);
                startActivity(intent);
            }
        });

        myLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", name3.getText().toString());
                bundle.putString("productPriceTv", price3.getText().toString());
                bundle.putString("fromBoolean", "main");
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.jacket1);
                startActivity(intent);
            }
        });

        myLayout4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", name4.getText().toString());
                bundle.putString("productPriceTv", price4.getText().toString());
                bundle.putString("fromBoolean", "main");
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.jacket2);
                startActivity(intent);
            }
        });

        myLayout5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, ProductActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("productNameTv", name5.getText().toString());
                bundle.putString("productPriceTv", price5.getText().toString());
                bundle.putString("fromBoolean", "main");
                intent.putExtras(bundle);
                intent.putExtra("productIv",R.drawable.shirt2);
                startActivity(intent);
            }
        });
    }

}