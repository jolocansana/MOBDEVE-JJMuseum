package ph.edu.dlsu.s12.nganj.exercise2;

import android.graphics.drawable.Drawable;

public class Cart {

    private String name = "";
    private String desc = "";
    private String price = "";
    private Drawable image ;

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public String getPrice() {
        return price;
    }

    public Drawable getImage() {
        return image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }
}
