package ph.edu.dlsu.s12.nganj.exercise2.utility;

import android.content.Context;
import android.content.SharedPreferences;

public class ModulePrefs {

    private SharedPreferences appPreferences;
    private final String PREFS = "appPreferences";

    public ModulePrefs(Context context){
        appPreferences = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    }

    public void saveStringPreferences(String key, String value){
        SharedPreferences.Editor prefsEditor = appPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();
    }

    public String getStringPreferences(String key) {
        return (appPreferences.getString(key,"Nothing Saved"));
    }

}

