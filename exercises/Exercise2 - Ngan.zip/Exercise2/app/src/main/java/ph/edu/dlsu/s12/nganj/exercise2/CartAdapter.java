package ph.edu.dlsu.s12.nganj.exercise2;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CartAdapter extends ArrayAdapter<Cart> {

    private Activity activity;
    private ArrayList<Cart> cartArrayList;

    public CartAdapter(Activity activity, ArrayList<Cart> cartArrayList){
        super(activity, R.layout.product_layout, cartArrayList);
        this.activity = activity;
        this.cartArrayList = cartArrayList;
    }

    public void addCart(Cart cart){
        cartArrayList.add(cart);
        notifyDataSetChanged();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View rowView = convertView;

        if (rowView == null){
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.product_layout, null);

            ViewHolder cartViewHolder = new ViewHolder();
            cartViewHolder.productName = (TextView) rowView.findViewById(R.id.productName);
            cartViewHolder.productDesc = (TextView) rowView.findViewById(R.id.productDesc);
            cartViewHolder.productPrice = (TextView) rowView.findViewById(R.id.productPrice);
            cartViewHolder.productImg = (ImageView) rowView.findViewById(R.id.productImg);

            rowView.setTag(cartViewHolder);
        }

        final ViewHolder holder = (ViewHolder) rowView.getTag();
        Cart info = cartArrayList.get(position);
        holder.productName.setText(info.getName());
        holder.productDesc.setText(info.getDesc());
        holder.productPrice.setText(info.getPrice());
        holder.productImg.setImageDrawable(info.getImage());

        return rowView;
    }

    static class ViewHolder{
        public TextView productName;
        public TextView productDesc;
        public TextView productPrice;
        public ImageView productImg;
    }

}
