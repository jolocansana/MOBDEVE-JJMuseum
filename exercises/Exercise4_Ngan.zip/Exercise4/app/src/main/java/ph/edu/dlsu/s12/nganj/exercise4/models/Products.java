package ph.edu.dlsu.s12.nganj.exercise4.models;


import java.io.Serializable;

public class Products implements Serializable {
    private String pname = "";
    private int quantity;
    private float cost;

    public Products() {

    }

    public Products(String pname, float cost, int quantity) {
        this.pname = pname;
        this.quantity = quantity;
        this.cost = cost;
    }

    public String getPname() {
        return pname;
    }

    public void setPname (String pname) {
        this.pname = pname;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }
}

