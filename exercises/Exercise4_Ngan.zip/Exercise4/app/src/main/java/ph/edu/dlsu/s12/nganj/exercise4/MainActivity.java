package ph.edu.dlsu.s12.nganj.exercise4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.exercise4.adapter.ItemsAdapter;
import ph.edu.dlsu.s12.nganj.exercise4.models.Items;
import ph.edu.dlsu.s12.nganj.exercise4.models.Products;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rv_list;
    private ArrayList<Items> itemsArrayList;
    private ItemsAdapter itemsAdapter;

    private Button btn_add;
    private Button btn_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle bundle = new Bundle();
        bundle = getIntent().getExtras();
        if(bundle !=null){
            String a = bundle.getString("comeFrom");

            Items newItems = new Items();
            itemsAdapter.addItem(newItems);
        }else{
            populateList();
            init();
        }
    }

    public void init() {
        rv_list = findViewById(R.id.rv_list);
        btn_add = findViewById(R.id.btn_add);
        btn_view = findViewById(R.id.btn_view);

        rv_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        itemsAdapter = new ItemsAdapter(getApplicationContext(), itemsArrayList);
        rv_list.setAdapter(itemsAdapter);

        btn_add.setOnClickListener(view -> {
            Toast.makeText(getApplicationContext(),
                    "Only implemented swipe",Toast.LENGTH_SHORT).show();
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                itemsArrayList.remove((viewHolder.getAdapterPosition()));
                itemsAdapter.notifyDataSetChanged();
            }
        }).attachToRecyclerView(rv_list);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                itemsArrayList.remove((viewHolder.getAdapterPosition()));
                itemsAdapter.notifyDataSetChanged();
            }
        }).attachToRecyclerView(rv_list);

    }

    private void populateList(){
        itemsArrayList = new ArrayList<>();
        Items sample = new Items();

        sample.setPdate("May 1, 2021");
        sample.setItemname("iStore");
        sample.setCourierID("10114246");
        sample.setOrderID("100-AAA-000-001");
        sample.addItem(new Products("IPhone 12", 60000.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 1, 2021");
        sample.setItemname("Huawei");
        sample.setCourierID("10114246");
        sample.setOrderID("100-HWI-999-998");
        sample.addItem(new Products("Mate 40 Pro", 60000.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 1, 2021");
        sample.setItemname("Sony");
        sample.setCourierID("10114246");
        sample.setOrderID("100-SNY-125-125");
        sample.addItem(new Products("Playstation 5", 28000.00f, 1));
        sample.addItem(new Products("Playstation 5 Controller", 2800.00f, 1));
        sample.addItem(new Products("Playstation 5 Game", 2800.00f, 1));
        sample.addItem(new Products("Playstation 5 Game", 2800.00f, 1));
        sample.addItem(new Products("Playstation 5 Game", 0.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 2, 2021");
        sample.setItemname("El Pollo Loco");
        sample.setCourierID("10114246");
        sample.setOrderID("100-ASD-322-552");
        sample.addItem(new Products("Fried Chicken", 600.00f, 1));
        sample.addItem(new Products("El Pollo Loco Special", 600.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 2, 2021");
        sample.setItemname("Sbarro");
        sample.setCourierID("10114246");
        sample.setOrderID("100-SBO-747-888");
        sample.addItem(new Products("Zitti Half White Sauce", 90.00f, 1));
        sample.addItem(new Products("California Deep Dish Pizza", 240.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 2, 2021");
        sample.setItemname("Jollibee");
        sample.setCourierID("10114246");
        sample.setOrderID("100-JBE-747-888");
        sample.addItem(new Products("Chickenjoy Meal", 120.00f, 1));
        sample.addItem(new Products("Burgersteak Meal", 70.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 3, 2021");
        sample.setItemname("Mexicali");
        sample.setCourierID("10114246");
        sample.setOrderID("100-USD-556-633");
        sample.addItem(new Products("French Fries", 240.00f, 1));
        sample.addItem(new Products("French Toast", 400.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 3, 2021");
        sample.setItemname("KFC");
        sample.setCourierID("10114246");
        sample.setOrderID("100-KFC-999-111");
        sample.addItem(new Products("Fried Chicken Solo", 140.00f, 1));
        sample.addItem(new Products("Brownies", 40.00f, 1));
        sample.addItem(new Products("Mac 'n Cheese", 40.00f, 1));
        sample.addItem(new Products("Iced Tea", 40.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 3, 2021");
        sample.setItemname("McDonald");
        sample.setCourierID("10114246");
        sample.setOrderID("100-GDP-876-901");
        sample.addItem(new Products("Big Mac Meal", 180.00f, 1));
        sample.addItem(new Products("Cheese Burger Meal", 120.00f, 1));
        sample.addItem(new Products("McSpaghetti", 90.00f, 1));
        sample.addItem(new Products("Choco Sundae", 40.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 4, 2021");
        sample.setItemname("Anne's Pastries");
        sample.setCourierID("10114246");
        sample.setOrderID("100-ANP-971-888");
        sample.addItem(new Products("Burnt Cheese Cake", 600.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 4, 2021");
        sample.setItemname("PizzaNelli's Neopolitan Pizza");
        sample.setCourierID("10114246");
        sample.setOrderID("100-ASA-902-734");
        sample.addItem(new Products("Shrimp Scampi", 600.00f, 1));
        itemsArrayList.add(0, sample);

        sample.setPdate("May 4, 2021");
        sample.setItemname("iStore");
        sample.setCourierID("10114246");
        sample.setOrderID("100-AAA-000-255");
        sample.addItem(new Products("Macbook Pro", 100000.00f, 1));
        itemsArrayList.add(0, sample);

        sample = new Items();
        sample.setPdate("May 5, 2021");
        sample.setItemname("Robinsons Grocery");
        sample.setCourierID("10114246");
        sample.setOrderID("100-ROB-421-341");
        sample.addItem(new Products("Milk", 80.00f, 1));
        sample.addItem(new Products("Yogurt Drink : Mixed Berry", 18.00f,24 ));
        sample.addItem(new Products("Yogurt Drink : StrawBerry", 18.00f,24 ));
        sample.addItem(new Products("Yogurt Drink : RaspBerry", 18.00f,24 ));
        sample.addItem(new Products("500g Chicken", 140.00f,1 ));
        sample.addItem(new Products("500g Bacon", 240.00f,1 ));
        sample.addItem(new Products("Paper Towel", 180.00f,1 ));
        sample.addItem(new Products("Soap", 50.00f,10 ));
        sample.addItem(new Products("Shampoo", 560.00f,1 ));
        sample.addItem(new Products("DishWashing Soap", 120.00f,1 ));
        sample.addItem(new Products("1KG Melon", 240.00f,1 ));
        sample.addItem(new Products("1KG Apple", 240.00f,1 ));
        sample.addItem(new Products("1KG Banana", 160.00f,1 ));
        sample.addItem(new Products("1KG Potato", 150.00f,1 ));
        sample.addItem(new Products("1KG Carrot", 160.00f,1 ));
        sample.addItem(new Products("Ham", 200.00f,1 ));
        sample.addItem(new Products("Embotido 200g", 250.00f,5 ));
        itemsArrayList.add(0, sample);
    }
}