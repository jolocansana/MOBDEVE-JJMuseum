package ph.edu.dlsu.s12.nganj.exercise4;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.exercise4.adapter.ProductsAdapter;
import ph.edu.dlsu.s12.nganj.exercise4.models.Items;
import ph.edu.dlsu.s12.nganj.exercise4.models.Products;

public class DetailsActivity extends AppCompatActivity {
    private TextView tv_vname;
    private TextView tv_vdate;
    private TextView tv_vorderID;
    private TextView tv_vcourierID;
    private RecyclerView rv_plist;

    private ArrayList<Products> productsArrayList;
    private ProductsAdapter productsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        init();
    }

    public void init () {
        tv_vname = findViewById(R.id.tv_vname);
        tv_vdate = findViewById(R.id.tv_vdate);
        tv_vorderID = findViewById(R.id.tv_vorderID);
        tv_vcourierID = findViewById(R.id.tv_vcourierID);
        rv_plist = findViewById(R.id.rv_plist);

        Bundle bundle = new Bundle();
        bundle = getIntent().getExtras();

        Items products = (Items) bundle.getSerializable("VendorRow");
        tv_vname.setText(products.getItemname());
        tv_vdate.setText(products.getPdate());
        tv_vorderID.setText(products.getOrderID());
        tv_vcourierID.setText(products.getCourierID());

        productsArrayList = products.getProductList();
        rv_plist.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        productsAdapter = new ProductsAdapter(getApplicationContext(), productsArrayList);
        rv_plist.setAdapter(productsAdapter);
    }

}