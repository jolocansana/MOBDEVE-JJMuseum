package ph.edu.dlsu.s12.nganj.exercise4.models;


import java.io.Serializable;
import java.util.ArrayList;

public class Items implements Serializable {
    private String itemname = "";
    private String pdate = "";
    private String orderID = "";
    private String courierID = "";
    private ArrayList<Products> productList;

    public Items(String itemname, String pdate, String orderID, String courierID) {
        this.itemname = itemname;
        this.pdate = pdate;
        this.orderID = orderID;
        this.courierID = courierID;
    }

    public Items(){
        this.productList = new ArrayList<Products>();
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getPdate() {
        return pdate;
    }

    public void setPdate(String pdate) {
        this.pdate = pdate;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getCourierID() {
        return courierID;
    }

    public void setCourierID(String courierID) {
        this.courierID = courierID;
    }

    public ArrayList<Products> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<Products> productList) {
        this.productList = productList;
    }

    public void addItem(Products products){
        productList.add(products);
    }

}