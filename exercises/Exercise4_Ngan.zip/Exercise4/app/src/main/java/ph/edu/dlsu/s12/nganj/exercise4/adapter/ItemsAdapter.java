package ph.edu.dlsu.s12.nganj.exercise4.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.exercise4.DetailsActivity;
import ph.edu.dlsu.s12.nganj.exercise4.R;
import ph.edu.dlsu.s12.nganj.exercise4.models.Items;

public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.ItemsViewHolder> {
    private ArrayList<Items> itemsArrayList;
    private Context context;

    public ItemsAdapter(Context context, ArrayList<Items> itemsArrayList){
        this.itemsArrayList = itemsArrayList;
        this.context = context;
    }

    @Override
    public int getItemCount() {
        return itemsArrayList.size();
    }

    public void addItem(Items newItem) {
        itemsArrayList.add(0, newItem);
        notifyItemInserted(0);
    }

    @Override
    public ItemsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_view, parent, false);

        ItemsViewHolder itemsViewHolder = new ItemsViewHolder(view);

        return itemsViewHolder;
    }

    @Override
    public void onBindViewHolder(final ItemsAdapter.ItemsViewHolder holder, final int position) {
        holder.tv_item.setText(itemsArrayList.get(position).getItemname());
        holder.tv_date.setText(itemsArrayList.get(position).getPdate());
        holder.tv_orderID.setText(itemsArrayList.get(position).getOrderID());
        holder.tv_courierID.setText(itemsArrayList.get(position).getCourierID());

        holder.btn_view.setOnClickListener(view -> {
            Intent intent = new Intent(context, DetailsActivity.class);
            intent.putExtra("VendorRow", itemsArrayList.get(position));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });
    }

    protected class ItemsViewHolder extends RecyclerView.ViewHolder{
        TextView tv_item;
        TextView tv_date;
        TextView tv_orderID;
        TextView tv_courierID;
        Button btn_view;

        public ItemsViewHolder(View view) {
            super(view);

            tv_item= view.findViewById(R.id.tv_item);
            tv_date = view.findViewById(R.id.tv_date);
            tv_orderID = view.findViewById(R.id.tv_orderID);
            tv_courierID = view.findViewById(R.id.tv_courierID);
            btn_view = view.findViewById(R.id.btn_view);
        }

    }
}
