package ph.edu.dlsu.s12.nganj.exercise4.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.util.ArrayList;

import ph.edu.dlsu.s12.nganj.exercise4.R;
import ph.edu.dlsu.s12.nganj.exercise4.models.Products;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ProductsViewHolder> {
    private ArrayList<Products> productsArrayList;
    private Context context;

    public ProductsAdapter(Context context, ArrayList<Products> productsArrayList) {
        this.context = context;
        this.productsArrayList = productsArrayList;
    }

    public void addItem(Products products){
        productsArrayList.add(0,products);
        notifyItemInserted(0);
        notifyDataSetChanged();

    }

    @Override
    public int getItemCount() {
        return productsArrayList.size();
    }

    @Override
    public ProductsAdapter.ProductsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product_view, parent, false);

        ProductsAdapter.ProductsViewHolder productsViewHolder = new ProductsAdapter.ProductsViewHolder(view);

        return productsViewHolder;
    }

    @Override
    public void onBindViewHolder(final ProductsAdapter.ProductsViewHolder holder, final int position) {
        holder.tv_pname.setText(productsArrayList.get(position).getPname() );
        holder.tv_quantity.setText(String.valueOf(new Integer(productsArrayList.get(position).getQuantity() )));

        DecimalFormat decimalFormat = new DecimalFormat();
        decimalFormat.setMaximumFractionDigits(1);

        holder.tv_cost.setText(decimalFormat.format(productsArrayList.get(position).getCost()) );

    }

    protected class ProductsViewHolder extends RecyclerView.ViewHolder{
        TextView tv_pname;
        TextView tv_quantity;
        TextView tv_cost;


        ProductsViewHolder(View view){
            super(view);
            tv_pname = view.findViewById(R.id.tv_pitem);
            tv_quantity = view.findViewById(R.id.tv_quantity);
            tv_cost = view.findViewById(R.id.tv_cost);
        }

    }
}
