package ph.edu.dlsu.s12.nganj.exercise1;

import android.app.Application;

public class MainApplication extends Application {

    public static String applicationName = "Exercise 1 - Jess Ngan";

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
