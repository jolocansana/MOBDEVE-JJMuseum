package ph.edu.dlsu.s12.nganj.exercise1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Welcome extends AppCompatActivity {

    private TextView display_username;
    private TextView product_name;
    private Button btn_view1;
    private Button btn_view2;
    private Button btn_view3;
    private Button btn_logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        String username = getIntent().getStringExtra("username");

        display_username = (TextView)findViewById(R.id.welcome_username);
        display_username.setText(username + "!");

        btn_view1 = (Button)findViewById(R.id.btn_view1);
        btn_view2 = (Button)findViewById(R.id.btn_view2);
        btn_view3 = (Button)findViewById(R.id.btn_view3);
        btn_logout = (Button)findViewById(R.id.btn_logout);

        btn_view1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                product_name = (TextView)findViewById(R.id.product_name1);

                Intent intent = new Intent(Welcome.this, Product.class);
                Bundle bundle = new Bundle();
                bundle.putString("product_name", product_name.getText().toString());
                bundle.putString("product_cat", "Funko Pop");
                bundle.putString("product_details", "Cute collective figure");
                intent.putExtras(bundle);
                intent.putExtra("img_sec1",R.drawable.funko);
                intent.putExtra("img_sec2",R.drawable.funko2);
                startActivity(intent);
            }
        });

        btn_view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                product_name = (TextView)findViewById(R.id.product_name2);

                Intent intent = new Intent(Welcome.this, Product.class);
                Bundle bundle = new Bundle();
                bundle.putString("product_name", product_name.getText().toString());
                bundle.putString("product_cat", "LoL T-shirts");
                bundle.putString("product_details", "Limited Edition League T-shirts");
                intent.putExtras(bundle);
                intent.putExtra("img_sec1",R.drawable.shirt1);
                intent.putExtra("img_sec2",R.drawable.shirt2);
                startActivity(intent);
            }
        });

        btn_view3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                product_name = (TextView)findViewById(R.id.product_name3);

                Intent intent = new Intent(Welcome.this, Product.class);
                Bundle bundle = new Bundle();
                bundle.putString("product_name", product_name.getText().toString());
                bundle.putString("product_cat", "LoL Hoodias");
                bundle.putString("product_details", "Limited Edition League Hoodies");
                intent.putExtras(bundle);
                intent.putExtra("img_sec1",R.drawable.jacket1);
                intent.putExtra("img_sec2",R.drawable.jacket2);
                startActivity(intent);
            }
        });

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Welcome.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {

        moveTaskToBack(true);
    }

}