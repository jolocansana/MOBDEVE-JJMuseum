package ph.edu.dlsu.s12.nganj.exercise1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Product extends AppCompatActivity {

    private TextView product_name;
    private TextView product_cat;
    private TextView product_details;
    private ImageView img_primary;
    private ImageView img_sec1;
    private ImageView img_sec2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        img_primary = (ImageView)findViewById(R.id.img_primary);
        img_sec1 = (ImageView)findViewById(R.id.img_sec1);
        img_sec2 = (ImageView)findViewById(R.id.img_sec2);
        product_name = (TextView)findViewById(R.id.product_name);
        product_cat = (TextView)findViewById(R.id.product_cat);
        product_details = (TextView)findViewById(R.id.product_details);

        Bundle bundle =  getIntent().getExtras();
        String prod_name = bundle.getString("product_name");
        String prod_cat = bundle.getString("product_cat");
        String prod_details = bundle.getString("product_details");
        int prod_img1 = bundle.getInt("img_sec1");
        int prod_img2 = bundle.getInt("img_sec2");


        product_name.setText(prod_name);
        product_cat.setText(prod_cat);
        product_details.setText(prod_details);
        img_primary.setImageResource(prod_img1);
        img_sec1.setImageResource(prod_img1);
        img_sec2.setImageResource(prod_img2);

        img_sec1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_primary.setImageResource(prod_img1);
            }
        });
        img_sec2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                img_primary.setImageResource(prod_img2);
            }
        });
    }

    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(Product.this, Welcome.class);
        startActivity(intent);

    }
}