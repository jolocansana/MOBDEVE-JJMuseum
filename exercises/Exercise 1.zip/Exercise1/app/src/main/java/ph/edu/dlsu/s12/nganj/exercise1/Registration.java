package ph.edu.dlsu.s12.nganj.exercise1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    private Button btn_submit;
    private EditText register_input_username;
    private EditText register_input_password;
    private EditText register_confirm_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        btn_submit = (Button)findViewById(R.id.btn_submit);
        register_input_username = (EditText)findViewById(R.id.register_input_username);
        register_input_password = (EditText)findViewById(R.id.register_input_password);
        register_confirm_password = (EditText)findViewById(R.id.register_confirm_password);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(register_input_username.getText().toString(),
                            register_input_password.getText().toString(),
                            register_confirm_password.getText().toString());
            }
        });
    }

    public void validate(String username, String input_password, String confirm_password) {
        if (username.length() >= 5) {
            if (input_password.length() >= 8) {
                if (confirm_password.equals(input_password)) {
                    Intent intent = new Intent(Registration.this, Welcome.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("username", username);
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Passwords do not match", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getApplicationContext(),
                        "Password must be atleast 8 characters long", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(getApplicationContext(),
                    "Username must be atleast 5 characters long", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(Registration.this, MainActivity.class);
        startActivity(intent);

    }
}