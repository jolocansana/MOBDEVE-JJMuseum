package ph.edu.dlsu.s12.cansana.addtocart;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ItemAdapter extends ArrayAdapter<Item> {
    private ArrayList<Item> itemArrayList;
    private Activity activity;

    public ItemAdapter (Activity activity, ArrayList<Item> itemArrayList) {
        super(activity, R.layout.list_item, itemArrayList);
        this.activity = activity;
        this.itemArrayList = itemArrayList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if(rowView == null){
            // create the layout
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.list_item, null);

            ViewHolder itemViewHolder = new ViewHolder();
            itemViewHolder.product_name = (TextView) rowView.findViewById(R.id.product_name);
            itemViewHolder.product_details = (TextView) rowView.findViewById(R.id.product_details);
            itemViewHolder.product_price = (TextView) rowView.findViewById(R.id.product_price);
            itemViewHolder.image = (ImageView) rowView.findViewById(R.id.image);
            // save the layout in memory
            rowView.setTag(itemViewHolder);
        }

        // Load layout

        final ViewHolder holder = (ViewHolder) rowView.getTag();
        Item info = itemArrayList.get(position);
        holder.product_name.setText(info.getProduct_name());
        holder.product_details.setText(info.getProduct_details());
        holder.product_price.setText(String.valueOf(info.getProduct_price()));
        int drawableId = this.getContext().getResources().getIdentifier(info.getImgNames().get(0), "drawable", getContext().getPackageName());
        holder.image.setImageResource(drawableId);

        return rowView;
    }

    static class ViewHolder {
        public TextView product_name, product_details, product_price;
        public ImageView image;
    }
}