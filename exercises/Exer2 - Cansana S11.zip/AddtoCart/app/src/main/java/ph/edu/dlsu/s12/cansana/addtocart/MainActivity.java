package ph.edu.dlsu.s12.cansana.addtocart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansana.addtocart.utility.ItemsForSale;
import ph.edu.dlsu.s12.cansana.addtocart.utility.ModulePrefs;

public class MainActivity extends AppCompatActivity {

    private ListView list;

    private Button btn_cart;

    private ItemAdapter itemAdapter;
    private ArrayList<Item> itemArrayList;

    private ItemsForSale itemsForSale;
    private ModulePrefs modulePrefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        itemAdapter = new ItemAdapter(this, itemArrayList);
        list.setAdapter(itemAdapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent ProductActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.addtocart.ProductActivity.class);
                Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                bundle.putInt("index", position);
                bundle.putStringArrayList("imgs", itemArrayList.get(position).getImgNames());
                bundle.putString("name", itemArrayList.get(position).getProduct_name());
                bundle.putInt("price", itemArrayList.get(position).getProduct_price());
                bundle.putString("description", itemArrayList.get(position).getProduct_details());
                bundle.putBoolean("isFromCart", false);
                ProductActivity.putExtras(bundle);
                startActivity(ProductActivity);
            }
        });

        btn_cart = (Button) findViewById(R.id.btn_cart);

        btn_cart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent CartActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.addtocart.CartActivity.class);
                startActivity(CartActivity);
            }
        });

    }

    private void init() {

        modulePrefs = new ModulePrefs(getApplicationContext());
//        String cart = modulePrefs.getStringPreferences("cart");
//        modulePrefs.saveStringPreferences("cart", cart);
//        Toast.makeText(getApplicationContext(), modulePrefs.getStringPreferences("cart"), Toast.LENGTH_SHORT).show();

        modulePrefs.saveStringPreferences("cart", "empty");// DELETE ME, this code is to reset cart on startup

        itemsForSale = new ItemsForSale();

        list = (ListView) findViewById(R.id.list);

        itemArrayList = itemsForSale.getItemArrayList();

    }
}