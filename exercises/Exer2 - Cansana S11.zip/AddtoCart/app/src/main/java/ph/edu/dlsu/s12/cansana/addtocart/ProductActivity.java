package ph.edu.dlsu.s12.cansana.addtocart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansana.addtocart.utility.CartParser;
import ph.edu.dlsu.s12.cansana.addtocart.utility.ModulePrefs;

public class ProductActivity extends AppCompatActivity {

    private TextView product, count_view;
    private EditText specialInstructions;
    private ImageView img;

    private Button btn_decrement, btn_increment, btn_add_item, btn_del_item;
    private String addBtnStr;

    private int count, total, cartIndex;
    private boolean isFromCart;

    private CartParser cartParser;
    private ModulePrefs modulePrefs;

    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        init();

        String product_details = String.format("%s - %d", bundle.getString("name"), bundle.getInt("price"));
        product.setText(product_details);
        img.setImageResource(this.getResources().getIdentifier(bundle.getStringArrayList("imgs").get(0),"drawable", this.getApplicationContext().getPackageName()));

        btn_decrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count > 1) count--;
                updateCounter();
            }
        });

        btn_increment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                updateCounter();
            }
        });

        btn_add_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedCartString;
                String specialInstructionStr = specialInstructions.getText().toString().equals("") ? "_" : specialInstructions.getText().toString();
                if(isFromCart) {
                    updatedCartString = cartParser.updateCart(modulePrefs.getStringPreferences("cart"),bundle.getInt("index"), count, specialInstructionStr);
                } else {
                    updatedCartString = cartParser.addToCart(modulePrefs.getStringPreferences("cart"),bundle.getInt("index"),count, specialInstructionStr);
                }
                modulePrefs.saveStringPreferences("cart", updatedCartString);
                //Toast.makeText(getApplicationContext(),modulePrefs.getStringPreferences("cart") ,Toast.LENGTH_SHORT).show();
                Intent CartActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.addtocart.CartActivity.class);
                startActivity(CartActivity);
                finish();
            }
        });

        btn_del_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedCartString = cartParser.removeFromCart(modulePrefs.getStringPreferences("cart"),bundle.getInt("index"));
                modulePrefs.saveStringPreferences("cart", updatedCartString);
                //Toast.makeText(getApplicationContext(),modulePrefs.getStringPreferences("cart"),Toast.LENGTH_SHORT).show();
                Intent CartActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.addtocart.CartActivity.class);
                startActivity(CartActivity);
                finish();
            }
        });
    }

    private void init() {
        modulePrefs = new ModulePrefs(getApplicationContext());

        cartParser = new CartParser();

        bundle = getIntent().getExtras();

        isFromCart = bundle.getBoolean("isFromCart");
        specialInstructions = (EditText) findViewById(R.id.special_instructions);

//        boolean isInCart = false;
        total = 0;

        ArrayList<Item> inCartItems;
//        Log.d("TAG", modulePrefs.getStringPreferences("cart"));
        inCartItems = cartParser.getCartFromString(modulePrefs.getStringPreferences("cart"));

        cartIndex = -1;

        if(inCartItems != null) {
            for (int i = 0; i < inCartItems.size(); i++) {
                if (inCartItems.get(i).getProduct_name().equals(bundle.getString("name"))) {
                    //isInCart = true;
                    cartIndex = i;
                }
                //total += inCartItems.get(i).getProduct_price();
            }
        }

        specialInstructions.setText(cartParser.getSpecialInstructions(modulePrefs.getStringPreferences("cart"),cartIndex));


        btn_decrement = (Button) findViewById(R.id.btn_decrement);
        btn_increment = (Button) findViewById(R.id.btn_increment);

        product = (TextView) findViewById(R.id.product);
        img = (ImageView) findViewById(R.id.picture);

        btn_del_item = (Button) findViewById(R.id.btn_remove_item);

        if(isFromCart){
            count = inCartItems.get(cartIndex).getProduct_price()/bundle.getInt("price");
            addBtnStr = "UPDATE CART";
        } else {
            count = 1;
            addBtnStr = "ADD TO CART";
            btn_del_item.setVisibility(View.GONE);
        }

        total = count*bundle.getInt("price");

        btn_add_item = (Button) findViewById(R.id.btn_add_item);
        btn_add_item.setText(addBtnStr + " - " + total);

        count_view = (TextView) findViewById(R.id.count);
        updateCounter();

    }

    private void updateCounter () {
        count_view.setText(Integer.toString(count));
        total = count*bundle.getInt("price");
        btn_add_item.setText(addBtnStr + " - " + total);
    }
}