package ph.edu.dlsu.s12.cansana.addtocart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import ph.edu.dlsu.s12.cansana.addtocart.utility.CartParser;
import ph.edu.dlsu.s12.cansana.addtocart.utility.ModulePrefs;
import ph.edu.dlsu.s12.cansana.addtocart.utility.ItemsForSale;

public class CartActivity extends AppCompatActivity {

    private ListView list;
    private TextView total_holder;
    private Button btn_place_order, btn_main;

    private ItemAdapter itemAdapter;

    private ArrayList<Item> cartItemArrayList;

    private CartParser cartParser;
    private ModulePrefs modulePrefs;
    private ItemsForSale itemsForSale;

    private int total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        init();

        if (cartItemArrayList != null) {
            itemAdapter = new ItemAdapter(this, cartItemArrayList);
            list.setAdapter(itemAdapter);

            total = 0;

            for(int i = 0; i < cartItemArrayList.size(); i++){
                total += cartItemArrayList.get(i).getProduct_price();
            }

            total_holder.setText(String.valueOf(total));
        } else {
            total_holder.setText("0");
        }

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent ProductActivity = new Intent(getApplicationContext(), ph.edu.dlsu.s12.cansana.addtocart.ProductActivity.class);

                String selectedItemName = cartItemArrayList.get(position).getProduct_name();
                ArrayList<Item> itemCatalogue = itemsForSale.getItemArrayList();
                Item itemDetails = new Item();

                int itemIndex = -1;

                for (int i = 0; i < itemCatalogue.size();i++) {
                    if(itemCatalogue.get(i).getProduct_name().equals(selectedItemName))
                    {
                        itemDetails = itemCatalogue.get(i);
                        itemIndex = i;
                    }
                }

                Bundle bundle = new Bundle(); // bundle data to transfer data across activities
                bundle.putInt("index", itemIndex);
                bundle.putStringArrayList("imgs", itemDetails.getImgNames());
                bundle.putString("name", itemDetails.getProduct_name());
                bundle.putInt("price", itemDetails.getProduct_price());
                bundle.putString("description", itemDetails.getProduct_details());
                bundle.putBoolean("isFromCart", true);
                ProductActivity.putExtras(bundle);
                startActivity(ProductActivity);
                finish();
            }
        });

        btn_place_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeOrder();
            }
        });

        btn_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void placeOrder() {
        modulePrefs.saveStringPreferences("cart", "empty");
        list.setVisibility(View.GONE);
        total_holder.setText("0");
        Toast.makeText(getApplicationContext(), "Order has been placed. Thank you", Toast.LENGTH_SHORT).show();
    }

    private void init() {
        list = (ListView) findViewById(R.id.list);
        total_holder = (TextView) findViewById(R.id.total);

        btn_place_order = (Button) findViewById(R.id.btn_place_order);
        btn_main = (Button) findViewById(R.id.btn_main);

        cartParser = new CartParser();
        modulePrefs = new ModulePrefs(getApplicationContext());
        itemsForSale = new ItemsForSale();

        // modulePrefs.saveStringPreferences("cart", "0,1\n1,2\n2,1");
        cartItemArrayList = cartParser.getCartFromString(modulePrefs.getStringPreferences("cart"));
    }
}