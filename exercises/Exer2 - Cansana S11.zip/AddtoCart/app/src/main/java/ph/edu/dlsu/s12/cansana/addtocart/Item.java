package ph.edu.dlsu.s12.cansana.addtocart;

import java.util.ArrayList;

public class Item {
    private ArrayList<String> imgNames;
    private String product_name, product_details;
    private int product_price, product_id;

    public Item() {}

    public Item(ArrayList<String> imgNames, String product_name, int product_price, String product_details) {
        this.imgNames = imgNames;
        this.product_name = product_name;
        this.product_details = product_details;
        this.product_price = product_price;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getProduct_price() {
        return product_price;
    }

    public void setProduct_price(int product_price) {
        this.product_price = product_price;
    }

    public String getProduct_details() {
        return product_details;
    }

    public void setProduct_details(String product_details) {
        this.product_details = product_details;
    }

    public ArrayList<String> getImgNames() {
        return imgNames;
    }

    public void setImgNames(ArrayList<String> imgNames) {
        this.imgNames = imgNames;
    }
}