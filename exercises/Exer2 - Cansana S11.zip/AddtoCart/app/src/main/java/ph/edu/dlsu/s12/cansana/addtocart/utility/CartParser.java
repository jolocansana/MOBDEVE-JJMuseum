package ph.edu.dlsu.s12.cansana.addtocart.utility;

import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;

import ph.edu.dlsu.s12.cansana.addtocart.Item;
import ph.edu.dlsu.s12.cansana.addtocart.utility.ModulePrefs;

public class CartParser {

    private ItemsForSale itemsForSale;

    public CartParser() {
        itemsForSale = new ItemsForSale();
    }

    public ArrayList<Item> getCartFromString(String string_cart) {

        if (string_cart.equals("empty"))
        {
            return null;
        }

        ArrayList<Item> cart = new ArrayList<>();

        String[] cart_contents = string_cart.split("\n");
        for (int i = 0; i < cart_contents.length; i++) {
            String[] item_details = cart_contents[i].split(",");
            // items saved as index,quantity
            Log.d("CARTPARSER",item_details[0]);
            int index = Integer.parseInt(item_details[0]);
            int quantity = Integer.parseInt(item_details[1]);
            ArrayList<Item> items = itemsForSale.getItemArrayList();
            Item item = items.get(index);
            cart.add(new Item(item.getImgNames(),item.getProduct_name(),item.getProduct_price()*quantity, item.getProduct_details()));
        }

        return cart;
    }

    public String getSpecialInstructions (String string_cart, int index) {
        String[] cart_contents = string_cart.split("\n");
        String specialInstructions = "";
        if (index != -1){
            for (int i = 0; i < cart_contents.length; i++) {
                String[] item_details = cart_contents[i].split(",");
                // items saved as index,quantity
                if(i == index){
                    specialInstructions = item_details[2].equals("_") ? "" : item_details[2];
                }
            }
        }

        return specialInstructions;
    }

    // addToCart
    public String addToCart (String string_cart, int index, int quantity, String specialIns) {
        boolean isNew = true;
        String updatedCart = "";

        String[] cart_contents = string_cart.split("\n");

        if(!(string_cart.equals("empty")))
        {
            for (int i = 0; i < cart_contents.length; i++) {
                String[] item_details = cart_contents[i].split(",");
                // items saved as index,quantity,special instruction
                if(Integer.parseInt(item_details[0]) == index){
                    item_details[1] = String.valueOf(Integer.parseInt(item_details[1]) + quantity);
                    item_details[2] = specialIns;
                    isNew = false;
                }

                updatedCart = updatedCart + String.format("%s,%s,%s\n", item_details[0], item_details[1], item_details[2]);
            }

            if (isNew) updatedCart = updatedCart + String.format("%s,%s,%s\n", index, quantity, specialIns);

        } else {
            updatedCart = String.format("%s,%s,%s\n", index, quantity,specialIns);
        }

        return updatedCart;
    }

    // updateCart
    public String updateCart (String string_cart, int index, int quantity, String specialIns) {
        boolean isNew = true;
        String updatedCart = "";

        String[] cart_contents = string_cart.split("\n");

        if(!(string_cart.equals("empty")))
        {
            for (int i = 0; i < cart_contents.length; i++) {
                String[] item_details = cart_contents[i].split(",");
                // items saved as index,quantity,special instruction
                if(Integer.parseInt(item_details[0]) == index){
                    item_details[1] = String.valueOf(quantity);
                    item_details[2] = specialIns;
                    isNew = false;
                }

                updatedCart = updatedCart + String.format("%s,%s,%s\n", item_details[0], item_details[1], item_details[2]);
            }

            if (isNew) updatedCart = updatedCart + String.format("%s,%s,%s\n", index, quantity, specialIns);

        } else {
            updatedCart = String.format("%s,%s,%s\n", index, quantity,specialIns);
        }

        return updatedCart;
    }

    // removeFromCart
    public String removeFromCart (String string_cart, int index) {
        String updatedCart = "";

        String[] cart_contents = string_cart.split("\n");
        for (int i = 0; i < cart_contents.length; i++) {
            String[] item_details = cart_contents[i].split(",");
            // items saved as index,quantity,special instructions
            if(Integer.parseInt(item_details[0]) != index){
                updatedCart = updatedCart + String.format("%s,%s,%s\n", item_details[0], item_details[1],item_details[2]);
            }
        }

        if (updatedCart.equals("")) updatedCart = "empty";

        return updatedCart;
    }

}
