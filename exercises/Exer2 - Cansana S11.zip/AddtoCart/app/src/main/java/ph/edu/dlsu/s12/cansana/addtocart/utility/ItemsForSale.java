package ph.edu.dlsu.s12.cansana.addtocart.utility;

import java.util.ArrayList;
import java.util.Arrays;

import ph.edu.dlsu.s12.cansana.addtocart.Item;


public class ItemsForSale {
    private ArrayList<Item> itemArrayList;

    public ItemsForSale() {
        itemArrayList = new ArrayList<>();

        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("pizza")), "Pepperoni Pizza", 300, "12-inch, triangle cut pepperoni and cheese pizza"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("burger")), "Angus Beef Burger", 400, "Angus Beef Burger with Tomato, Cheese, Lettuce, Onion"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("cookie")), "Chocolate Chip Cookie", 100, "Chocolate chip Regular sized baked cookie"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("coke")), "Coke", 50, "Coke Can 12oz"));
        itemArrayList.add(new Item(new ArrayList<>(Arrays.asList("sprite")), "Sprite", 50, "Sprite Can 12oz"));
    }

    public ArrayList<Item> getItemArrayList() {
        return itemArrayList;
    }

    public void setItemArrayList(ArrayList<Item> itemArrayList) {
        this.itemArrayList = itemArrayList;
    }
}
