package ph.edu.dlsu.s12.nganj.androidchallenge1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class NewActivity extends AppCompatActivity {

    private Button btn_discard;
    private Button btn_send;
    private EditText receiverEt;
    private EditText subjectEt;
    private EditText contentEt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        init();


        btn_send.setOnClickListener((View v)->{
            Intent intent = new Intent(NewActivity.this, MainActivity.class);

            SharedPreferences prefs = getSharedPreferences("sharedPreferences", MODE_PRIVATE);;
            SharedPreferences.Editor editor = prefs.edit();

            String receiver = receiverEt.getText().toString();
            String subject = subjectEt.getText().toString();
            String content = contentEt.getText().toString();
            String status = "Draft";

            if(receiver != "" && subject != "" && content != ""){
                editor.putString("e_receiver", receiverEt.getText().toString());
                editor.putString("e_subject", subjectEt.getText().toString());
                editor.putString("e_content", contentEt.getText().toString());

                if(receiver != "" || subject != "" || content != "")
                    editor.putString("e_status",status);
                editor.commit();
            }


            startActivity(intent);

        });

    }

    private void init(){
        btn_discard = (Button)findViewById(R.id.btn_discard);
        btn_send = (Button)findViewById(R.id.btn_send);
        receiverEt = (EditText)findViewById(R.id.receiverEt);
        subjectEt = (EditText)findViewById(R.id.subjectEt);
        contentEt = (EditText)findViewById(R.id.contentEt);

    }
}