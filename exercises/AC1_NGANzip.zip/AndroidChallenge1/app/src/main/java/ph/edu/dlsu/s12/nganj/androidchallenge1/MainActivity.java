package ph.edu.dlsu.s12.nganj.androidchallenge1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    private Button btn_latest;
    private Button btn_new;
    private TextView draftTv;
    private ListView emailList;
    private ArrayList<Email> emailArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();


        btn_new.setOnClickListener((View v)->{
                Intent intent = new Intent(MainActivity.this, NewActivity.class);
                startActivity(intent);
        });


/*
           emailList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    //Edit Drafts

                }
            });

        }
*/

        btn_latest.setOnClickListener((View v)->{

            Intent intent = new Intent(getApplicationContext(), LatestActivity.class);

            Bundle bundle = new Bundle();

            String receive =  emailArrayList.get(emailArrayList.size()-1).getReceiver().toString();

            bundle.putString("e_receiver",receive);
            bundle.putString("e_receiver", emailArrayList.get(emailArrayList.size()-1).getReceiver().toString());
            bundle.putString("e_subject", emailArrayList.get(emailArrayList.size()-1).getSubject().toString());
            bundle.putString("e_content", emailArrayList.get(emailArrayList.size()-1).getContent().toString());

            intent.putExtras(bundle);

            startActivity(intent);
                });

    }

    private void init(){

        btn_latest = (Button)findViewById(R.id.btn_latest);
        btn_new = (Button)findViewById(R.id.btn_new);
        emailList = (ListView)findViewById(R.id.email_list);
        draftTv = (TextView)findViewById(R.id.draftTv);
    }



    protected void onResume(){
        super.onResume();
        
        loadEmails();

        EmailAdapter emailAdapter = new EmailAdapter(this, emailArrayList);
        emailList.setAdapter(emailAdapter);

        createEmail();
        saveEmail();
    }

    protected void onDestroy(){
        super.onDestroy();

        SharedPreferences sharedPreferences = getSharedPreferences("sharedPreferences",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();

    }

    private void createEmail(){
        SharedPreferences prefs = getSharedPreferences("sharedPreferences", MODE_PRIVATE);;

        String e_receiver = prefs.getString("e_receiver", "");
        String e_content = prefs.getString("e_content", "");
        String e_subject= prefs.getString("e_subject", "");
        String e_status = prefs.getString("e_status","");



        if(!(e_receiver == null || e_receiver == "")){

            Email email = new Email();
            email.setReceiver(e_receiver);
            email.setContent(e_content);
            email.setSubject(e_subject);

            emailArrayList.add(email);
        }


    }

    private void saveEmail(){
        SharedPreferences sharedPreferences=getSharedPreferences("sharedPreferences",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        Gson gson = new Gson();
        String json=gson.toJson(emailArrayList);
        editor.putString("emailLists",json);
        editor.apply();
    }


    private void loadEmails(){

        SharedPreferences sharedPreferences = getSharedPreferences("sharedPreferences",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("emailLists",null);
        Type type = new TypeToken<ArrayList<Email>>(){}.getType();

        emailArrayList=gson.fromJson(json,type);
/*
        for(int i = 0; i < emailArrayList.size(); i++) {
            if(emailArrayList.get(i).getStatus() != "Draft")
                draftTv.setVisibility(View.GONE);
        }
*/
        if(emailArrayList==null){
            emailArrayList = new ArrayList<>();
        }


        int list = emailArrayList.size();
        String ct = String.valueOf(list);
        Toast.makeText(this, "load" + ct, Toast.LENGTH_LONG).show();

    }

}