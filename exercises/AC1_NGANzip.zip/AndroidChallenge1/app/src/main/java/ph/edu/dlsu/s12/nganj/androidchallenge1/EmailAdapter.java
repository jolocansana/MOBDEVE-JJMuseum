package ph.edu.dlsu.s12.nganj.androidchallenge1;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class EmailAdapter extends ArrayAdapter<Email> {
    private Activity activity;
    private ArrayList<Email> emailArrayList;


    public EmailAdapter(Activity activity, ArrayList<Email> emailArrayList){
        super(activity,R.layout.email_layout,emailArrayList);
        this.emailArrayList=emailArrayList;
        this.activity=activity;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;

        if(rowView==null){
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.email_layout,null);

            ViewHolder viewHolder = new ViewHolder();
            viewHolder.receiverTv = (TextView) rowView.findViewById(R.id.receiverTv);
            viewHolder.subjectTv = (TextView) rowView.findViewById(R.id.subjectTv);
            viewHolder.contentTv = (TextView) rowView.findViewById(R.id.contentTv);

            rowView.setTag(viewHolder);

        }else{}

        final ViewHolder holder = (ViewHolder) rowView.getTag();
        Email email = emailArrayList.get(position);

        holder.receiverTv.setText(email.getReceiver());
        holder.subjectTv.setText(email.getSubject());
        holder.contentTv.setText(email.getContent());

        return rowView;
    }

    static class ViewHolder{
        public TextView receiverTv;
        public TextView subjectTv;
        public TextView contentTv;
    }
}
