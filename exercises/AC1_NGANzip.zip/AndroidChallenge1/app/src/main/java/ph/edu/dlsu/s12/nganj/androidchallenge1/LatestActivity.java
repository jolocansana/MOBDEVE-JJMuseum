package ph.edu.dlsu.s12.nganj.androidchallenge1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LatestActivity extends AppCompatActivity {

    private TextView latest_receiverTv;
    private TextView latest_subjectTv;
    private TextView latest_contentTv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latest);

        init();

        Bundle bundle =  getIntent().getExtras();

        String receiver = bundle.getString("e_receiver");
        String subject = bundle.getString("e_subject");
        String content = bundle.getString("e_content");

        latest_receiverTv.setText(receiver);
        latest_subjectTv.setText(subject);
        latest_contentTv.setText(content);
    }

    private void init(){
        latest_receiverTv = (TextView)findViewById(R.id.latest_receiverTv);
        latest_subjectTv = (TextView)findViewById(R.id.latest_subjectTv);
        latest_contentTv = (TextView)findViewById(R.id.latest_contentTv);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}