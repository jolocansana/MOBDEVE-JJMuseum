package ph.edu.dlsu.s12.nganj.androidchallenge1;

public class Email {

    private String e_receiver;
    private String e_subject;
    private String e_content;
    private String e_status;

    public String getStatus() {
        return e_status;
    }

    public void setStatus(String e_status) {
        this.e_status = e_status;
    }

    public String getReceiver() {
        return e_receiver;
    }

    public void setReceiver(String e_receiver) {
        this.e_receiver = e_receiver;
    }

    public String getSubject() {
        return e_subject;
    }

    public void setSubject(String e_subject) {
        this.e_subject = e_subject;
    }

    public String getContent() {
        return e_content;
    }

    public void setContent(String e_content) {
        this.e_content = e_content;
    }
}
