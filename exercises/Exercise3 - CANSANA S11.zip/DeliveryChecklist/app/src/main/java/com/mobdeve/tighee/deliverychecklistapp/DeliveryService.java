package com.mobdeve.tighee.deliverychecklistapp;

import android.app.IntentService;
import android.content.Intent;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import androidx.annotation.Nullable;

public class DeliveryService extends IntentService {

    private Message message;

    public DeliveryService() {
        super(DeliveryService.class.getName());
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        final Messenger messenger = intent.getParcelableExtra("handler");

        for(int i = 0; i < 6; i++){
            try {
                Thread.sleep(10000); // 10 second delay between tasks
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            message = new Message();
            message.what = i; // i+1 indicates the task number done
            try {
                messenger.send(message);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        message = new Message();
        message.what = -1; // -1 means done
        try {
            messenger.send(message);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

}
