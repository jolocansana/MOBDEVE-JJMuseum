package com.mobdeve.tighee.deliverychecklistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tv_time;
    private TextView tv_amount;
    private ImageView iv_status_01;
    private ImageView iv_status_02;
    private ImageView iv_status_03;
    private ImageView iv_status_04;
    private ImageView iv_status_05;
    private ImageView iv_status_06;
    private ImageView iv_complete;

    private Intent serviceIntent = null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init(){
        tv_amount = findViewById(R.id.tv_amount);
        tv_time = findViewById(R.id.tv_time);

        Date date = new Date();
        Locale philippineLocale = new Locale.Builder().setLanguage("en").setRegion("PH").build();

        tv_time.setText(getDate(date, philippineLocale));

        tv_amount.setText("Total Amount :\n500.00");
        serviceIntent = new Intent(this, DeliveryService.class);

        iv_status_01 = (ImageView) findViewById(R.id.iv_status_01);
        iv_status_02 = (ImageView) findViewById(R.id.iv_status_02);
        iv_status_03 = (ImageView) findViewById(R.id.iv_status_03);
        iv_status_04 = (ImageView) findViewById(R.id.iv_status_04);
        iv_status_05 = (ImageView) findViewById(R.id.iv_status_05);
        iv_status_06 = (ImageView) findViewById(R.id.iv_status_06);
        iv_complete = (ImageView) findViewById(R.id.iv_complete);

        registerservice();
    }



    private void registerservice(){

        serviceIntent = new Intent(getApplicationContext(), DeliveryService.class);

        serviceIntent.putExtra("handler", new Messenger(mHandler));

        startService(serviceIntent);
    }


    @Override
    protected void onDestroy(){
        super.onDestroy();
        stopService(serviceIntent);
    }


    private String getDate(Date date, Locale locale) {
        DateFormat formatter = new SimpleDateFormat("EEEE \nMMMM dd, yyyy", locale);
        return formatter.format(date);
    }

    public final Handler mHandler =  new Handler() {
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case -1:
                    iv_complete.setVisibility(View.VISIBLE);
                    iv_complete.setImageResource(R.drawable.complete);
                    break;
                case 0:
                    iv_status_01.setImageResource(R.drawable.box_check);
                    break;
                case 1:
                    iv_status_02.setImageResource(R.drawable.box_check);
                    break;
                case 2:
                    iv_status_03.setImageResource(R.drawable.box_check);
                    break;
                case 3:
                    iv_status_04.setImageResource(R.drawable.box_check);
                    break;
                case 4:
                    iv_status_05.setImageResource(R.drawable.box_check);
                    break;
                case 5:
                    iv_status_06.setImageResource(R.drawable.box_check);
                    break;
                default:
                    break;
            }
        }
    };
}